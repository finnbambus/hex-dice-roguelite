// Browser UI.
// Layout: left rail (run state) · board stage with the hand on top of it · right panel (the current step).
// The step panel walks the player through a round: Roll → Result → Build & trade → … → Tribute → Shop.
// Each step shows only what is possible right now; one main button moves the game forward.
// The UI also implements the engine's `io` interface (board clicks and choice dialogs).
import { Game, COSTS, BLINDS } from './game.js';
import { RES, TERRAIN_RES, pips } from './board.js';
import { ITEMS, ITEM_LIST, BOSS_BY_ID, ROLLS_PER_ROUND, LOADING, START_SETTLEMENTS, ECHO_BREAK } from './content.js';
import { BoardView } from './board-view.js?v=63';
import { figure, faceBody, primaryTrigger } from './figures.js?v=63';
import { Feel } from './feel.js?v=63';
import { Anim, EASE_OUT } from './anim.js?v=63';

const TERRAIN_COLOR = { hills: '#c8734a', forest: '#3f7d4a', pasture: '#9ccf6a', fields: '#e8c547', mountains: '#8e939c', desert: '#e3d3a4' };
const RES_ICON = { brick: 'B', lumber: 'L', wool: 'W', grain: 'G', ore: 'O' };
const FACE_LABEL = { mirror: 'M', robber: 'R7', blank: '?' };
const SETTER_ITEM = { mirror: 'mirror', robber: 'robberFace', blank: 'blank' };
const TRIG_LABEL = { lucky: 'L', knightFav: 'kF', knightLucky: 'kL', robberFav: 'rF', robberLucky: 'rL', hidden: 'H' };
// The guided tutorial: each step points at a real part of the screen (a missing target gets a centred card).
const TUTORIAL = [
  { title: 'Welcome to Hex & Dice', text: 'You run one island through an endless series of rounds. Each round you roll dice to earn resources, build, and then pay a <b>tribute</b>. Pay it every time and keep upgrading your dice and island; miss one and the run is over.' },
  { sel: '#board .world', pad: -30, title: 'Your island', text: 'Every hex pays out its resource when its number is rolled, to each of your buildings touching it (settlement 1 card, city 2). More dots under a number means it comes up more often; 6 and 8 are best. You start by placing free settlements and roads on the orange dots.' },
  { sel: '#hand .zone:first-child', title: 'Your hand', text: 'Resources you hold sit in stacks here. Roads, settlements, cities and cards cost resources. Careful: a rolled <b>7</b> makes you discard down to 7 cards and moves the robber, which blocks a hex.' },
  { sel: '#hand .zone:nth-child(2)', title: 'Cards and guilds', text: '<b>Cards</b> are single-use: click one to pick it, then press Play. <b>Guilds</b> are permanent bonuses. You find both in the shop. Hover anything for the details.', alsoSel: '#hand .zone.guilds' },
  { sel: '#panel .act-head', title: 'A round has three steps', text: '<b>Roll</b> the dice (up to 4 rolls per round), <b>build and trade</b> between rolls, then pay the <b>tribute</b>. The run card above it shows whether this is the Small, Big or Boss round of the ante. This card always shows what you can do right now, and the big button moves you on.' },
  { sel: '#tribute', title: 'The boss and the tribute', text: 'Under the ante: its <b>boss</b>, whose drawback only applies in the Boss round. Below that, the <b>tribute</b> you must hand over at the end of the round, one bar per resource. The tribute grows every ante, and the Boss round also needs three different resource types.' },
  { sel: '#panel .dice-stage', fallback: '#panel .panel-body', title: 'The dice', text: 'You roll two dice. The total decides which hexes pay. Drag a die to spin it and see every face; click it for a list of its faces and upgrades. Upgrading faces is how you bend the odds.' },
  { sel: '.vp-zone', alsoSel: '.stat-zone', title: 'Score and titles', text: '<b>Score</b> is your victory points: settlements 1, cities 2, VP cards, plus bonus for the <b>longest road</b> and the <b>largest army</b> (the two small cards, hover them for details). Unused rolls add VP too.' },
  { title: 'The shop', text: 'After the tribute is paid, whatever VP you have becomes your <b>shop budget</b> (unspent VP is lost). Buy upgrades for your dice faces, number tokens, hexes and ports, plus cards and guilds. Then the next round starts, and it is harder. Good luck!' },
];

const MOD_INFO = {
  nudge: ['Nudge', 'Change this die by ±1 (once per round).'],
  recast: ['Recast', 'Reroll this die (once per round).'],
  alchemist: ['Alchemist', 'Set this die to any value (once per round).'],
  twin: ['Twin Die · reroll', 'Reroll this die instead of keeping its result. Once per round, and the new result is final: there is no going back. To keep the current result, just use the roll.'],
};
const CAT_LABEL = { face: 'Dice · face', die: 'Dice · whole die', token: 'Field · number token', hex: 'Field · hex', port: 'Field · port', classic: 'Card · single use', edict: 'Edict · single use', guild: 'Guild · always on', charter: 'Charter · instant' };
const PRE_ROLL_CARDS = ['bumper', 'omen', 'monopoly'];
const STEPS = [['roll', 'Roll'], ['build', 'Build & trade'], ['tribute', 'Tribute']]; // the result of a roll is part of the Roll step
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const resDot = (r) => `<span class="res-dot" style="background:var(--${r})"></span>`;
const HL_MS = 3600; // how long a roll's highlights (pulses, +1 badges) stay lit
const PACK_T = { first: 450, gap: 380, turn: 480 }; // an opened pack: when the first card turns, the pause between cards, one turn (ms at normal speed)
const PULSE = [{ boxShadow: '0 0 0 0 rgba(255, 74, 28, .95)' }, { boxShadow: '0 0 0 12px rgba(255, 74, 28, 0)' }]; // a ring in the shape of whatever it is played on
const DROP = [ // a piece set down on the board: it appears a little above its spot and falls
  { translate: '0 -58px', opacity: 0, easing: 'cubic-bezier(.5, 0, .9, .45)' },
  { translate: '0 -46px', opacity: 1, offset: 0.22, easing: 'cubic-bezier(.5, 0, .9, .45)' },
  { translate: '0 0', opacity: 1, offset: 0.72, easing: 'ease-out' },
  { translate: '0 -5px', opacity: 1, offset: 0.86, easing: 'ease-in' },
  { translate: '0 0', opacity: 1 },
];
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
// Printed things sit a little off-axis. The tilt is steady: the same card always leans the same way.
const hs = (str) => [...String(str)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 7);
const tilt = (n, amp) => { const r = Math.sin(n * 127.1 + 311.7) * 43758.5453; return +((r - Math.floor(r) - 0.5) * 2 * amp).toFixed(2); };

// Halftone art is printed straight onto the card stock: one cell of the 5 × 4 art sheet per subject.
const ART_CELL = { brick: 13, lumber: 14, wool: 15, grain: 16, ore: 17 };
const artPos = (i) => `${((i % 5) * 100) / 4}% ${(Math.floor(i / 5) * 100) / 3}%`;
// A hand turn of a die happens in screen space; the cube sits inside the tilted view, so undo the tilt around it.
const TILT = { normal: ['rotateY(24deg) rotateX(52deg)', 'rotateX(-52deg) rotateY(-24deg)'], choosing: ['rotateY(-28deg) rotateX(22deg)', 'rotateX(-22deg) rotateY(28deg)'] };
const spunTransform = (m, choosing) => { const [inv, t] = TILT[choosing ? 'choosing' : 'normal']; return `${inv} ${m} ${t} `; };
const rcard = (r, cls = '', style = '', attr = '') => `<div class="rcard ${cls}" style="--c:var(--${r});${style}" ${attr}><i class="dot"></i><span class="art" style="background-position:${artPos(ART_CELL[r])}"></span><span class="nm">${cap(r)}</span></div>`;
// Art for the cards you hold, by item (falls back to the category).
const CARD_ART = { knight: 5, marshal: 5, cartographer: 4, roadBuilding: 4, townCharter: 4, royalCharter: 3, vpCard: 3, forgery: 3, yearOfPlenty: 8, monopoly: 12, granary: 8, mathematicians: 0, twinFortune: 1, longShot: 0, firePriests: 9, squatters: 4, monoculture: 6, deepPockets: 3, guildExpansion: 3, highwayCharter: 4, lostFound: 3, taxCollector: 3, robbersFriend: 5, moneylender: 3, tradeConsul: 3 };
const CAT_ART = { classic: 5, edict: 11, guild: 3, charter: 3, face: 0, die: 1, token: 0, hex: 7, port: 3 };
const CAT_DOT = { classic: '#d4a845', edict: '#a8b872', guild: '#8494ad', charter: '#b5593f' };
const CAT_SHORT = { classic: 'Card', edict: 'Edict', guild: 'Guild', charter: 'Charter' };
// A die face drawn as a face: pips for numbers, the special marks for mirror / robber / blank faces.
const PIP_AT = { 1: [[50, 50]], 2: [[28, 28], [72, 72]], 3: [[28, 28], [50, 50], [72, 72]], 4: [[28, 28], [72, 28], [28, 72], [72, 72]], 5: [[28, 28], [72, 28], [50, 50], [28, 72], [72, 72]], 6: [[28, 26], [72, 26], [28, 50], [72, 50], [28, 74], [72, 74]] };
const svgUrl = (body) => `url('data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>${body}</svg>`).replace(/'/g, '%27').replace(/\(/g, '%28').replace(/\)/g, '%29')}')`;
// Triggers other than the one whose symbol is drawn on the face get a short label in the corner.
const extraTrg = (f) => { const p = f.setter ? null : primaryTrigger(f.triggers); return [...new Set(f.triggers)].filter((t) => t !== p).map((t) => TRIG_LABEL[t]).join(''); };
const faceArt = (f, loaded) => {
  const tone = loaded ? '#e6cf8c' : '#e9e4d6';
  let bg = tone, inner = '';
  if (f.setter === 'mirror') bg = `${svgUrl("<circle cx='50' cy='50' r='22' fill='none' stroke='#f0ead8' stroke-opacity='.14' stroke-width='30'/><circle cx='50' cy='50' r='22' fill='none' stroke='#f0ead8' stroke-opacity='.3' stroke-width='17'/><circle cx='50' cy='50' r='27' fill='#e9e4d6'/><circle cx='50' cy='50' r='17' fill='#17181b'/>")} center/100% 100% no-repeat, #17181b`;
  else if (f.setter === 'robber') { bg = '#17181b'; inner = '<span class="lbl">R</span>'; }
  else if (f.setter === 'blank') { bg = '#17181b'; inner = '<span class="lbl">?</span>'; }
  else if (f.triggers.length) bg = `${svgUrl(faceBody(f.value, f.triggers))} center/100% 100% no-repeat, ${tone}`;
  else bg = `${svgUrl(PIP_AT[f.value].map((q) => `<circle cx='${q[0]}' cy='${q[1]}' r='8.5' fill='#17181b'/>`).join(''))} center/100% 100% no-repeat, ${tone}`;
  const ex = f.triggers.length ? extraTrg(f) : '';
  const marks = ex ? `<i class="trg">${ex}</i>` : '';
  return `<span class="fa" style="background:${bg}">${inner}${marks}</span>`;
};
const UPGRADE_CATS = ['face', 'die', 'token', 'hex', 'port'];
const cardArt = (it) => artPos(CARD_ART[it.id] ?? CAT_ART[it.cat] ?? 3);

export class UI {
  constructor() {
    this.game = null;
    this.busy = false;
    this.boardReq = null;
    this.modal = null; // a pending choice from the engine
    this.dialog = null; // help / new run
    this.drawer = null; // 'log' | 'dev'
    this.tributeTypes = null;
    this.tradeGive = null;
    this.hoverCost = null;
    this.preBuild = false;
    this.tips = new Map(); // detail cards registered during the latest render, by key
    this.tipKey = null; // the detail card on screen
    this.pinnedTip = null; // a detail card opened by click stays until clicked again
    this.hlReport = null; // the roll report whose highlights are running
    this.hlStart = 0;
    this.hlMap = new Map(); // change key → highlight for that element
    this.$tip = document.createElement('div');
    this.$tip.className = 'card-tip';
    this.$tip.hidden = true;
    document.body.appendChild(this.$tip);
    this.dieSheet = null; // which die's face sheet is open (0 | 1 | null)
    this.$board = document.getElementById('board');
    this.view = new BoardView(this.$board);
    this.$prompt = document.getElementById('prompt');
    this.$overlay = document.getElementById('overlay');
    this.$panel = document.getElementById('panel');
    this.$hand = document.getElementById('hand');
    this.$hud = document.getElementById('hud');
    this.$stage = document.getElementById('stage');
    this.$tribute = document.getElementById('tribute');
    this.feel = new Feel({ board: this.$board, lamp: this.$stage.querySelector('.lamp') });
    this.anim = new Anim(this.$stage); // flights, drops, flips; see anim.js
    this.feel.off = () => !this.anim.on;
    this.animPrev = null; // the state the last render showed, to spot what to animate
    this.hideCards = new Set(); // cards in hand that are still on their way there (hidden until they land)
    this.lastPick = null; // where the last shop pick was on screen: a bought card flies in from there
    this.revealQ = Promise.resolve(); // development card reveals play one after another
    this.flown = new WeakSet(); // roll reports whose payout has already been flown in
    this.bars = { id: '', pcts: [] }; // tribute bars as last drawn, so they can grow instead of jumping
    this.shown = null; // what the last render showed, so changes can count up and drop in
    this.logSeen = 0;
    this.prevPhase = null;
    this.payout = null; // the roll payout whose drop-in animation is running
    this.stamp = null; // a "tribute paid" moment
    this.selCard = null;
    this.spin = [null, null]; // how far the player has turned each die by hand
    this.drag = null;
    this.tipsOpen = false;
    this.tipsSeen = false;
    this.tutSeen = false;
    this.tut = null;
    try { this.tutSeen = localStorage.getItem('hd-tutorial') === 'seen'; } catch { /* storage can be blocked */ }
    try { this.tipsSeen = localStorage.getItem('hd-tips') === 'seen'; } catch { /* storage can be blocked */ }
    this.$drawer = document.getElementById('drawer');
    this.$modal = document.getElementById('modal-root');
    // Testing tools are for the author: shown on localhost or with ?dev in the address, hidden for players.
    this.dev = new URLSearchParams(location.search).has('dev') || /^(localhost|127\.0\.0\.1|)$/.test(location.hostname);
    document.documentElement.classList.toggle('dev', this.dev);
    this.bindEvents();
  }

  // ---------------------------------------------------------------- lifecycle
  newGame(seed) {
    Object.assign(this, { boardReq: null, modal: null, dialog: null, busy: false, tributeTypes: null, tradeGive: null, preBuild: false, shown: null, logSeen: 0, prevPhase: null, payout: null, stamp: null });
    this.feel.tw.clear();
    this.feel.holds.clear();
    this.anim.reset();
    this.animPrev = null;
    this.hideCards.clear();
    this.lastPick = null;
    this.revealQ = Promise.resolve();
    this.orbsOut = 0;
    this.bars = { id: '', pcts: [] };
    const g = new Game({ seed, io: this });
    this.game = g;
    g.onChange = () => this.render();
    try {
      const url = new URL(location.href);
      url.searchParams.set('seed', g.seed);
      history.replaceState(null, '', url);
    } catch { /* sandboxed frames may refuse URL changes */ }
    this.run(() => g.start());
  }

  async run(fn) {
    if (this.busy) return;
    this.busy = true;
    this.render();
    try {
      await fn();
    } catch (e) {
      console.error(e);
      this.game?.log(`Error: ${e.message}`, 'bad');
    } finally {
      this.busy = false;
      this.render();
    }
  }

  // ---------------------------------------------------------------- io interface
  requestBoard(kind, ids, prompt, opts = {}) {
    if (!ids || !ids.length) return Promise.resolve(null);
    return new Promise((resolve) => {
      this.boardReq = { kind, ids: new Set(ids), prompt, cancel: opts.cancel !== false, resolve };
      this.render();
    });
  }
  chooseVertex(ids, p, o) { return this.requestBoard('vertex', ids, p, o); }
  chooseEdge(ids, p, o) { return this.requestBoard('edge', ids, p, o); }
  chooseHex(ids, p, o) { return this.requestBoard('hex', ids, p, o); }
  choosePort(ids, p, o) { return this.requestBoard('port', ids, p, o); }
  openModal(m) {
    return new Promise((resolve) => {
      this.modal = { ...m, resolve };
      this.render();
    });
  }
  chooseOption(options, prompt, o = {}) { return this.openModal({ type: 'options', options, prompt, cancel: !!o.cancel }); }
  chooseFace(options, prompt, o = {}) { return this.openModal({ type: 'face', options, prompt, cancel: !!o.cancel }); }
  // In the shop, Loaded and die upgrades are placed on the dice in a workbench over the shop.
  chooseLoad(options, prompt, o = {}) { return this.openModal({ type: 'load', options, prompt, cancel: !!o.cancel, sel: null }); }
  chooseDie(options, prompt, o = {}) {
    if (this.game?.phase !== 'shop') return this.chooseOption(options, prompt, o);
    return this.openModal({ type: 'die', options, prompt, cancel: !!o.cancel });
  }
  chooseResources(n, prompt, o = {}) {
    return this.openModal({ type: 'resources', n, prompt, cancel: !!o.cancel, max: o.max || null, counts: Object.fromEntries(RES.map((r) => [r, 0])) });
  }
  discard(n, prompt, o = {}) {
    return this.openModal({ type: 'resources', n, prompt, cancel: false, max: o.max, counts: Object.fromEntries(RES.map((r) => [r, 0])), discard: true });
  }
  resolveModal(value) {
    const m = this.modal;
    this.modal = null;
    m?.resolve(value);
    this.render();
  }
  resolveBoard(value) {
    const b = this.boardReq;
    this.boardReq = null;
    b?.resolve(value);
    this.render();
  }

  // ---------------------------------------------------------------- which step is shown
  step() {
    const g = this.game;
    if (!g || g.phase === 'init' || g.phase === 'setup') return 'setup';
    if (g.phase !== 'turn') return g.phase; // tribute | shop | gameover
    if (g.pendingRoll) return 'adjust';
    if (g.report && g.report.stage === 'result' && !g.report.seen) return 'result';
    if (g.rollsUsed === 0 && !g.echoQueue.length && !this.preBuild) return 'roll';
    return 'build';
  }

  // ---------------------------------------------------------------- events
  bindEvents() {
    document.addEventListener('click', (ev) => {
      const t = ev.target.closest('[data-top]');
      if (t) return this.onTop(t.dataset.top);
      const a = ev.target.closest('[data-a]');
      if (a && !a.disabled) this.onAction(a.dataset.a, a.dataset, a);
    });
    // Pressing a button or a key finishes whatever is still animating: nothing ever has to be waited for.
    document.addEventListener('pointerdown', (ev) => {
      if (this.anim.busy && ev.target.closest?.('button, [data-a], [data-top], .fx-dim')) this.anim.skip();
    }, true);
    // Shop offers and pack picks lean toward the pointer.
    document.addEventListener('pointermove', (ev) => this.tiltAt(ev));
    document.documentElement.addEventListener('mouseleave', () => this.tiltAt(null));
    // Animation speed (menu).
    const seg = document.getElementById('opt-anim');
    if (seg) {
      const paint = () => {
        for (const b of seg.querySelectorAll('[data-speed]')) { b.classList.toggle('on', b.dataset.speed === (this.anim.reduced ? 'off' : this.anim.speed)); b.disabled = this.anim.reduced; }
        if (this.anim.reduced) seg.parentElement.title = 'Off: your system asks for reduced motion';
        const sw = document.getElementById('opt-shake');
        if (sw) { sw.disabled = this.feel.reduced; sw.checked = this.feel.shakeOn; }
      };
      seg.addEventListener('click', (ev) => {
        const b = ev.target.closest('[data-speed]');
        if (!b) return;
        this.anim.setSpeed(b.dataset.speed);
        if (!this.anim.on) { this.feel.holds.clear(); this.feel.tw.clear(); this.hideCards.clear(); }
        paint();
        this.render();
      });
      paint();
    }
    // Detail cards: hover shows one, click keeps it open (buttons keep their own clicks).
    document.addEventListener('pointerover', (ev) => {
      const pf = ev.target.closest?.('[data-a="pick-face"]');
      if (pf) this.pickPreview(`${pf.dataset.die}-${pf.dataset.face}`);
      if (this.pinnedTip) return;
      const el = ev.target.closest?.('[data-tip]');
      if (el && el.dataset.tip !== this.tipKey) this.openTip(el.dataset.tip, el);
    });
    document.addEventListener('pointerout', (ev) => {
      if (ev.target.closest?.('[data-a="pick-face"]') && !ev.relatedTarget?.closest?.('[data-a="pick-face"]')) this.pickPreview(null);
      if (this.pinnedTip) return;
      if (!ev.relatedTarget?.closest?.('[data-tip]')) this.hideTip();
    });
    document.addEventListener('click', (ev) => {
      if (ev.target.closest('button, [data-a], [data-top]')) return;
      const el = ev.target.closest('[data-tip]');
      if (el) {
        if (this.pinnedTip === el.dataset.tip) this.unpinTip();
        else this.pinTip(el.dataset.tip, el);
      } else if (this.pinnedTip) this.unpinTip();
    });
    this.$board.addEventListener('click', (ev) => {
      const el = ev.target.closest('[data-k]');
      if (!el || !this.boardReq) return;
      const id = Number(el.dataset.id);
      if (el.dataset.k === this.boardReq.kind && this.boardReq.ids.has(id)) this.resolveBoard(id);
    });
    // Pointing at a resource anywhere (hand, tribute, trade, pay choices) lights the hexes that produce it.
    document.addEventListener('pointerover', (ev) => {
      const el = ev.target.closest?.('[data-res], [data-r]');
      const r = el && !el.closest('#board') ? (el.dataset.res || el.dataset.r) : null;
      if (r !== this.resHover) { this.resHover = RES.includes(r) ? r : null; this.applyResFocus(); }
      const bp = !!ev.target.closest?.('.boss-row');
      if (bp !== !!this.bossPreview) { this.bossPreview = bp; if (this.game?.board) { this.renderBoard(); this.applyResFocus(); } }
    });
    // Turn a die by hand: drag it. A drag never counts as a click, so it does not open the face sheet.
    document.addEventListener('pointerdown', (ev) => {
      const d = ev.target.closest?.('.die3d[data-cube]');
      if (!d || ev.button > 0) return;
      const i = Number(d.dataset.cube);
      this.drag = { i, el: d, x: ev.clientX, y: ev.clientY, moved: false, base: this.spin[i] ? new DOMMatrix(this.spin[i]) : new DOMMatrix() };
    });
    document.addEventListener('pointermove', (ev) => {
      const dr = this.drag;
      if (!dr) return;
      const dx = ev.clientX - dr.x, dy = ev.clientY - dr.y;
      if (!dr.moved && Math.hypot(dx, dy) < 5) return;
      dr.moved = true;
      // Turn in screen space, like a trackball: the side under the pointer follows it.
      const ang = Math.hypot(dx, dy) * 0.7;
      this.spin[dr.i] = new DOMMatrix().rotateAxisAngleSelf(-dy, dx, 0, ang).multiply(dr.base).toString();
      const cube = dr.el.querySelector('.cube');
      if (cube) { cube.style.transition = 'none'; cube.style.animation = 'none'; cube.style.transform = `${spunTransform(this.spin[dr.i], !!cube.closest('.choosing'))}${cube.style.getPropertyValue('--final')}`; }
    });
    const endDrag = () => { if (this.drag?.moved) { this.dragMoved = true; setTimeout(() => { this.dragMoved = false; }, 0); } this.drag = null; };
    document.addEventListener('pointerup', endDrag);
    document.addEventListener('pointercancel', endDrag);
    document.addEventListener('dblclick', (ev) => {
      const d = ev.target.closest?.('.die3d[data-cube]');
      if (d) { this.spin[Number(d.dataset.cube)] = null; this.render(); }
    });
    // Clicking a field on the island focuses it (again, or empty sea, to let go). Not while the board is asking for a pick.
    document.addEventListener('click', (ev) => {
      if (!ev.target.closest?.('#board') || this.boardReq || ev.target.closest('[data-k], button')) return;
      const h = this.view?.hexAt(this.game?.board, ev.clientX, ev.clientY);
      const id = h ? h.id : null;
      this.hexFocus = id === this.hexFocus ? null : id;
      this.applyResFocus();
    });
    // A picked card is put back when you click anywhere else.
    document.addEventListener('click', (ev) => {
      if (this.selCard != null && !ev.target.closest('.slot-wrap')) { this.selCard = null; this.render(); }
    });
    // The ? tips popover closes when you click anywhere else.
    document.addEventListener('click', (ev) => {
      if (this.tipsOpen && !ev.target.closest('.tips-pop, .tip-btn')) { this.tipsOpen = false; this.render(); }
    });
    const mb = document.getElementById('menu-btn');
    const mp = document.getElementById('menu-pop');
    this.setMenu = (open) => { mp.hidden = !open; mb.setAttribute('aria-expanded', String(open)); };
    mb.addEventListener('click', (ev) => { ev.stopPropagation(); this.setMenu(mp.hidden); });
    document.addEventListener('click', (ev) => { if (!mp.hidden && (!ev.target.closest('.menu') || ev.target.closest('[data-top]'))) this.setMenu(false); });
    const sw = document.getElementById('opt-shake');
    if (sw) {
      sw.checked = this.feel.shakeOn;
      sw.disabled = this.feel.reduced;
      if (this.feel.reduced) sw.parentElement.title = 'Off: your system asks for reduced motion';
      sw.addEventListener('change', () => this.feel.setShake(sw.checked));
    }
    // Hovering a build option highlights the cards it would use in the hand.
    this.$panel.addEventListener('mouseover', (ev) => {
      const el = ev.target.closest('[data-cost]');
      const cost = el ? COSTS[el.dataset.cost] : null;
      if (cost !== this.hoverCost) { this.hoverCost = cost; this.renderHand(); }
    });
    this.$panel.addEventListener('mouseleave', () => { if (this.hoverCost) { this.hoverCost = null; this.renderHand(); } });
    document.addEventListener('keydown', (ev) => {
      if (ev.target.matches('input, select')) {
        if (ev.key === 'Enter' && ev.target.id === 'new-seed') this.onAction('start-seed', {});
        return;
      }
      if ((ev.key === ' ' || ev.key === 'Enter' || ev.key === 'Escape') && this.anim.busy) {
        const reveal = this.anim.dims > 0; // a card reveal is up: the key only fast-forwards it
        this.anim.skip();
        if (reveal) { ev.preventDefault(); return; }
      }
      if (this.tut) {
        if (ev.key === 'Escape') this.endTutorial();
        else if (ev.key === 'ArrowRight' || ev.key === 'Enter') this.tutStep(1);
        else if (ev.key === 'ArrowLeft') this.tutStep(-1);
        ev.preventDefault();
        return;
      }
      if (ev.key === 'Escape') {
        if (!document.getElementById('menu-pop').hidden) this.setMenu(false);
        else if (this.peek) { this.peek = false; this.render(); }
        else if (this.hexFocus != null) { this.hexFocus = null; this.applyResFocus(); }
        else if (this.selCard != null) { this.selCard = null; this.render(); }
        else if (this.tipsOpen) { this.tipsOpen = false; this.render(); }
        else if (this.dieSheet != null) { this.dieSheet = null; this.render(); }
        else if (this.pinnedTip) this.unpinTip();
        else if (this.boardReq?.cancel) this.resolveBoard(null);
        else if (this.modal?.cancel) this.resolveModal(null);
        else if (this.dialog) { this.dialog = null; this.render(); }
        else if (this.drawer) { this.drawer = null; this.render(); }
        return;
      }
      if (this.dialog === 'title' && (ev.key === 'Enter' || ev.key === ' ')) { ev.preventDefault(); this.dialog = null; this.render(); return; }
      if (this.busy || this.modal || this.dialog || this.boardReq) return;
      if (ev.key === 'Enter' || ev.key === ' ') {
        const btn = this.$stage.querySelector('.panel [data-primary]:not([disabled]), .over [data-primary]:not([disabled])');
        if (btn) { ev.preventDefault(); btn.click(); }
      }
    });
  }

  onTop(k) {
    if (k === 'new') this.dialog = 'new';
    if (k === 'help') this.dialog = 'help';
    if (k === 'tutorial') return this.startTutorial();
    if (k === 'log' || k === 'dev') this.drawer = this.drawer === k ? null : k;
    this.render();
    if (k === 'new') setTimeout(() => document.getElementById('new-seed')?.focus(), 0);
  }

  onAction(a, d, el) {
    // Where a shop pick sits on screen: the card it gives flies to the hand from there.
    if (a === 'buy' || (a === 'opt' && el?.classList.contains('pick-offer'))) {
      const art = (el.closest('.offer') || el).querySelector('.o-stage > *');
      if (art) this.lastPick = { rect: art.getBoundingClientRect(), t: performance.now() };
    }
    // A pack that is still turning its cards over: the first click only shows them.
    if (a === 'opt' && this.modal?.pack && !this.packShown(this.modal)) { this.modal.t0 = -1e9; return this.render(); }
    if (a === 'tips') {
      this.tipsOpen = !this.tipsOpen;
      this.tipsSeen = true;
      try { localStorage.setItem('hd-tips', 'seen'); } catch { /* ignore */ }
      return this.render();
    }
    if (a === 'pick-card') { this.selCard = this.selCard === Number(d.uid) ? null : Number(d.uid); this.tipsOpen = false; return this.render(); }
    this.selCard = null;
    this.tipsOpen = false;
    if (a !== 'die-sheet' && a !== 'die-open') this.dieSheet = null;
    if ((a === 'die-sheet' || a === 'pick-face') && this.dragMoved) return;
    if (a === 'pick-face' && this.modal?.type === 'load') {
      const m = this.modal;
      const o = m.options.find((x) => x.die === Number(d.die));
      if (!o || o.disabled) return;
      const L = this.game.dice[o.die].loaded;
      m.sel = { die: o.die, face: L ? L.face : Number(d.face) };
      return this.render();
    }
    if (a === 'load-confirm') { const m = this.modal; return m?.sel ? this.resolveModal({ ...m.sel }) : undefined; }
    if (a === 'bench-die') {
      const m = this.modal;
      const o = m?.options.find((x) => x.value === Number(d.die));
      return o && !o.disabled ? this.resolveModal(o.value) : undefined;
    }
    if (a === 'pick-face') {
      const m = this.modal;
      const opt = m?.type === 'face' ? m.options.find((o) => o.die === Number(d.die) && o.face === Number(d.face)) : null;
      return opt ? this.resolveModal(opt) : undefined;
    }
    if (a === 'die-sheet') { this.dieSheet = this.dieSheet === Number(d.die) ? null : Number(d.die); this.render(); return this.revealSheet(); }
    if (a === 'die-open') { this.dieSheet = Number(d.die); this.render(); return this.revealSheet(); }
    if (a === 'die-close') return this.render();
    const g = this.game;
    switch (a) {
      // dialogs & choices
      case 'opt': return this.resolveModal(this.modal.options[Number(d.i)].value);
      case 'face': return this.resolveModal(this.modal.options[Number(d.i)]);
      case 'cancel-modal': return this.resolveModal(null);
      case 'cancel-board': return this.resolveBoard(null);
      case 'close-dialog': this.dialog = null; return this.render();
      case 'title-tutorial': this.dialog = null; this.render(); return this.startTutorial();
      case 'close-drawer': this.drawer = null; return this.render();
      case 'drawer-tab': this.drawer = d.tab; return this.render();
      case 'res-inc': case 'res-dec': {
        const m = this.modal;
        const total = RES.reduce((s, r) => s + m.counts[r], 0);
        if (a === 'res-inc' && total < m.n && (!m.max || m.counts[d.r] < m.max[d.r])) m.counts[d.r]++;
        if (a === 'res-dec' && m.counts[d.r] > 0) m.counts[d.r]--;
        return this.render();
      }
      case 'res-ok': return this.resolveModal({ ...this.modal.counts });
      case 'random-seed': this.dialog = null; return this.newGame(Math.floor(Math.random() * 1e9));
      case 'start-seed': {
        const v = Number(document.getElementById('new-seed')?.value);
        this.dialog = null;
        return this.newGame(v || Math.floor(Math.random() * 1e9));
      }
      // turn flow
      case 'roll': this.preBuild = false; return this.run(() => g.roll());
      case 'resolve': return this.run(() => g.resolveRoll());
      case 'tutorial': return this.startTutorial();
      case 'tut-next': return this.tutStep(1);
      case 'tut-back': return this.tutStep(-1);
      case 'tut-end': return this.endTutorial();
      case 'mod': return this.run(() => g.useModifier(Number(d.die), d.id));
      case 'seen': if (g.report) g.report.seen = true; return this.render();
      case 'prebuild': this.preBuild = true; return this.render();
      case 'end': this.preBuild = false; this.tradeGive = null; g.endRound(); return;
      case 'build': this.hoverCost = null; return this.run(() => g.build(d.kind));
      case 'play': return this.run(() => g.playCard(Number(d.uid)));
      case 'sell': this.selCard = null; return this.run(() => g.sellCard(Number(d.uid)));
      case 'give': this.tradeGive = this.tradeGive === d.r ? null : d.r; return this.render();
      case 'get': {
        if (!this.tradeGive) return;
        g.trade(this.tradeGive, d.r);
        if (g.hand[this.tradeGive] < g.tradeRate(this.tradeGive)) this.tradeGive = null;
        return this.render();
      }
      case 'ship': g.ship(Number(d.port), d.r, d.mode); return;
      case 'ship-mixed': return this.run(() => g.shipMixed(Number(d.port)));
      // tribute
      case 'tpick': this.tributeTypes[Number(d.i)] = d.r; return this.render();
      case 'pay': if (g.payTribute(this.tributeTypes)) this.tributeTypes = null; return;
      case 'fail': g.failTribute(); return;
      // shop
      case 'buy': return this.run(() => g.buy(Number(d.i)));
      case 'reroll': g.rerollShop(); return;
      case 'reroll-boss': g.rerollBoss(); return;
      case 'leave': this.peek = false; g.leaveShop(); return;
      case 'peek': this.peek = !this.peek; return this.render();
      // game over
      case 'again': return this.newGame(g.seed);
      case 'fresh': return this.newGame(Math.floor(Math.random() * 1e9));
      // dev
      case 'dev-res': g.devGive(d.r, Number(d.n)); return;
      case 'dev-budget': g.devBudget(10); return;
      case 'dev-force': {
        g.devForce = [Number(document.getElementById('dev-d1').value), Number(document.getElementById('dev-d2').value)];
        g.log(`Dev: next roll forced to ${g.devForce.join('+')}.`);
        return this.render();
      }
      case 'dev-item': {
        const id = document.getElementById('dev-item').value;
        return this.run(() => g.devItem(id));
      }
      case 'dev-shop': if (g.phase === 'turn' && !g.pendingRoll) { g.earned.unusedRolls = 0; g.finishTribute(true); } return;
    }
  }

  // ---------------------------------------------------------------- render
  render() {
    const g = this.game;
    if (!g || !g.board) { this.renderModal(); return; }
    this.tips = new Map();
    this.syncHighlights();
    const moments = this.spotMoments();
    this.detectMoments();
    this.renderTribute();
    this.renderBoard();
    this.renderPrompt();
    this.renderOverlay();
    this.renderPanel();
    this.renderHand();
    this.renderMood();
    this.renderDrawer();
    this.renderModal();
    this.refreshTip();
    if (!document.querySelector('[data-res]:hover, [data-r]:hover')) this.resHover = null; // the element under the pointer may have been replaced
    this.applyResFocus();
    this.playMoments(moments);
    this.anim.sync();
  }

  // ---------------------------------------------------------------- moments (drops, counting, shake)
  later(fn, ms) { setTimeout(fn, Math.max(0, ms)); }

  // Milliseconds until the dice of the current roll have landed (0 when none is tumbling).
  landIn() {
    const g = this.game;
    if (!(g.rollSeq > 0)) return 0;
    const T = this.anim.ms(880);
    if (g.rollSeq !== this.seenSeq) return T;
    return Math.max(0, T - (performance.now() - (this.rollStart || 0)));
  }

  // Runs once per render, before anything is drawn: spots what just happened and starts the matching effects.
  detectMoments() {
    const g = this.game;
    const now = performance.now();
    const land = this.landIn();

    // heavy hits from the log: the boss, the robber, a building lost
    const lines = g.logLines || [];
    if (this.logSeen > lines.length) this.logSeen = lines.length;
    let hit = 0;
    for (const l of lines.slice(this.logSeen)) {
      const bad = /\bbad\b/.test(l.cls || '');
      if (/burn|raze|sack|destroyed by lava/i.test(l.msg) || /^Tribute failed/.test(l.msg)) hit = 3;
      else if (bad && (g.blind === 2 || /robber|Discarded|Barbarian|ERUPTION/i.test(l.msg))) hit = Math.max(hit, 2);
      else if (bad) hit = Math.max(hit, 1);
    }
    this.logSeen = lines.length;
    if (hit) this.later(() => this.feel.hit(hit, 'bad'), land + 200);

    // the tribute is paid, or a boss round begins
    if (this.prevPhase === 'tribute' && g.phase === 'shop') {
      const boss = g.blind === 2;
      const hold = this.anim.ms(boss ? 2000 : 1400);
      this.stamp = { start: now + 120, hold: now + hold, boss }; // the shop opens after the stamp has landed
      this.later(() => this.feel.hit(boss ? 3 : 2, 'good'), 280);
      this.later(() => this.render(), hold + 30);
    } else if (this.prevPhase === 'shop' && g.phase === 'turn' && g.blind === 2) {
      this.later(() => this.feel.hit(2, 'bad'), 200);
    }
    this.prevPhase = g.phase;

    // numbers that change count up (cards in hand, score); a roll's payout waits for the dice to land
    const cur = { vp: g.vpBreakdown().total };
    for (const r of RES) cur[`hand-${r}`] = g.hand[r];
    const fresh = this.payout?.fresh;
    if (this.payout) this.payout.fresh = false;
    if (this.shown) {
      for (const [k, v] of Object.entries(cur)) {
        const old = this.shown[k];
        if (k === 'vp' && this.anim.on) { // orbs carry the score to the counter, one point each (playMoments)
          if (v > old) this.feel.hold('vp', this.feel.value('vp', old));
          else if (v < old) this.feel.release('vp');
          continue;
        }
        if (v > old) {
          const from = this.feel.value(k, old);
          if (fresh) {
            const gain = v - old;
            this.feel.count(k, from, v, k === 'vp' ? land + 560 : land + 330, k === 'vp' ? 360 + 110 * gain : 220 + 80 * gain);
          } else this.feel.count(k, from, v, 0, 380);
        } else if (v < old) this.feel.tw.delete(k);
      }
    }
    this.shown = cur;
  }

  // ---------------------------------------------------------------- animated moments (flights, drops, reveals; see anim.js)
  // The game has already resolved by the time any of this plays: the two methods below compare what the last
  // render showed with what is true now and replay the difference.
  animSnap() {
    const g = this.game;
    return {
      hand: { ...g.hand },
      cards: (g.cards || []).map((c) => ({ uid: c.uid, id: c.id })),
      guilds: (g.guilds || []).map((c) => ({ uid: c.uid, id: c.id })),
      buildings: { ...g.buildings },
      roads: new Set(g.roads || []),
      vp: g.vpBreakdown(),
      phase: g.phase,
      step: this.step(),
      ante: g.ante,
      blind: g.blind,
      bossLive: g.blind === 2 && g.phase !== 'shop' && g.phase !== 'gameover',
    };
  }

  // Before the redraw: what changed, where leaving cards lay, and which arriving cards stay hidden until they land.
  spotMoments() {
    const A = this.anim;
    const prev = this.animPrev, cur = this.animSnap();
    this.animPrev = cur;
    this.rollNow = !!this.payout?.fresh; // this render shows a roll that has just resolved
    if (!prev || !A.on) { if (!A.on) this.hideCards.clear(); return null; }
    const m = { prev, cur, land: this.landIn(), roll: this.rollNow, gone: [], came: [] };
    for (const [kind, list] of [['card', 'cards'], ['guild', 'guilds']]) {
      for (const c of prev[list]) {
        if (cur[list].some((x) => x.uid === c.uid)) continue;
        const key = `${kind}:${c.uid}`;
        const rect = this.hideCards.has(key) ? null : this.$hand.querySelector(`[data-tip="${key}"]`)?.getBoundingClientRect();
        this.hideCards.delete(key);
        if (rect && rect.width) m.gone.push({ id: c.id, rect });
      }
      for (const c of cur[list]) {
        if (prev[list].some((x) => x.uid === c.uid)) continue;
        const key = `${kind}:${c.uid}`;
        this.hideCards.add(key);
        m.came.push({ key, id: c.id });
      }
    }
    return m;
  }

  // After the redraw: start the animations for what spotMoments found.
  playMoments(m) {
    if (!m) return;
    const A = this.anim, g = this.game, B = g.board;
    const { prev, cur, land } = m;
    const shopPick = g.phase === 'shop' && this.lastPick && performance.now() - this.lastPick.t < 60000 ? this.lastPick : null;

    // resources: a roll's production flies from its field into the hand (all fields at once); anything spent,
    // paid, discarded or stolen is drawn out of its stack and fades
    const rep = g.report;
    const pays = m.roll && rep?.pays?.length && !this.flown.has(rep) ? rep.pays : null;
    if (pays) { this.flown.add(rep); this.flyPays(pays, land); }
    for (const r of RES) {
      const d = cur.hand[r] - prev.hand[r];
      if (d > 0) {
        if (prev.hand[r] === 0 && pays?.some((p) => p.res === r)) A.play(`stack:${r}`, [{ opacity: 0 }, { opacity: 1 }], { dur: 430, wait: land, ease: 'steps(1, end)' });
        if (!m.roll) A.play(`gain:${r}`, PULSE, { dur: 700 });
      } else if (d < 0) this.liftRes(r, Math.min(-d, 5), land);
    }

    // cards and guilds: played, sold or discarded ones are drawn out and fade; new ones are revealed, or fly in from the shop
    m.gone.forEach((c, i) => A.after(land, () => { if (ITEMS[c.id]) A.lift(A.add(this.miniCard(ITEMS[c.id]), 'low', 82), c.rect, 82, { side: i % 2 ? 1 : -1 }); }));
    for (const c of m.came) {
      if (shopPick) this.flyBought(c, shopPick.rect);
      else this.queueReveal(c, land);
    }

    // pieces set down on the board
    const newB = Object.keys(cur.buildings).filter((v) => cur.buildings[v] && cur.buildings[v] !== prev.buildings[v]);
    const newR = [...cur.roads].filter((e) => !prev.roads.has(e));
    for (const v of newB) A.play(`b:${v}`, DROP, { dur: 440, ease: 'linear' });
    for (const e of newR) A.play(`r:${e}`, DROP, { dur: 400, ease: 'linear' });
    if (newB.length || newR.length) this.later(() => this.feel.sound('drop'), A.ms(300));

    // score: one orb per point, from whatever earned it, into the counter
    const dv = cur.vp.total - prev.vp.total;
    if (dv > 0) {
      const mid = (r) => (r && r.width ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null);
      const centre = () => this.view.toScreen(520, 385);
      const stat = (k) => () => mid(this.$hud.querySelector(`.stat.${k}`)?.getBoundingClientRect()) || centre();
      const now = [], later = [];
      const push = (list, n, fn) => { for (let i = 0; i < n && now.length + later.length < dv; i++) list.push(typeof fn === 'function' ? fn : fn[i % fn.length]); };
      const dB = cur.vp.settlements + cur.vp.cities - prev.vp.settlements - prev.vp.cities;
      const dC = cur.vp.vpCards - prev.vp.vpCards;
      push(now, dB, newB.length ? newB.map((v) => () => { const p = this.view.vertexScreen(B.vertices[v]); return { x: p.x, y: p.y - 26 * p.s }; }) : centre);
      push(now, cur.vp.road - prev.vp.road, newR.length ? () => this.view.edgeScreen(B, B.edges[newR[newR.length - 1]]) : stat('road'));
      push(now, cur.vp.army - prev.vp.army, stat('army'));
      if (dC > 0 && shopPick) push(now, dC, () => mid(shopPick.rect));
      else push(later, dC, centre); // a Victory Point card drawn from the stack is revealed first
      push(now, dv, centre); // anything else
      this.sendOrbs(now.slice(0, dv - later.length), land + A.ms(newB.length || newR.length ? 400 : 160), 0);
      if (later.length) this.queueReveal({ key: null, id: 'vpCard' }, land).then((pt) => this.sendOrbs(later.map(() => () => pt || centre()), 0, now.length));
    }
    if (shopPick && (m.came.length || cur.vp.vpCards > prev.vp.vpCards)) this.lastPick = null;

    // the action card and the indicators change step without a hard cut
    const stepOf = (s) => (s === 'adjust' || s === 'result' ? 'roll' : s);
    if (cur.step !== prev.step) {
      A.play('panel', [{ opacity: 0, translate: '0 10px' }, { opacity: 1, translate: '0 0' }], { dur: 300 });
      if (stepOf(cur.step) !== stepOf(prev.step)) {
        A.play('step-on', [{ opacity: 0.3 }, { opacity: 1 }], { dur: 460 });
        A.play('step-dot', [{ scale: '0.2', boxShadow: '0 0 0 0 rgba(236, 235, 230, .7)' }, { scale: '1.5', offset: 0.5 }, { scale: '1', boxShadow: '0 0 0 9px rgba(236, 235, 230, 0)' }], { dur: 560 });
      }
    }
    if (cur.blind !== prev.blind || cur.ante !== prev.ante) {
      A.play('round-on', [{ opacity: 0.3 }, { opacity: 1 }], { dur: 520 });
      A.play('round-dot', [{ scale: '0.2' }, { scale: '1.7', offset: 0.5 }, { scale: '1' }], { dur: 600, pseudo: '::before' });
      A.play('trib', [{ opacity: 0, translate: '0 8px' }, { opacity: 1, translate: '0 0' }], { dur: 380, delay: 120 });
    }
    if (cur.ante !== prev.ante) A.play('ante', [{ opacity: 0, translate: '0 10px', color: '#ff4a1c' }, { opacity: 1, translate: '0 0', color: '#ff4a1c', offset: 0.45 }, { opacity: 1, translate: '0 0' }], { dur: 900 });
    if (cur.bossLive && !prev.bossLive) A.play('boss-live', [{ opacity: 0, translate: '0 -8px' }, { opacity: 1, translate: '0 0' }], { dur: 560, delay: 160 });
    if (cur.phase === 'setup' && cur.roads.size > prev.roads.size) {
      const n = cur.roads.size;
      for (const i of [n - 1, n]) A.play(`seg:${i}`, [{ transform: 'scaleX(0)' }, { transform: 'scaleX(1)' }], { dur: 380, delay: i === n ? 160 : 0 });
    }
  }

  stackRect(r) { const b = this.$hand.querySelector(`.stack[data-res="${r}"] .stack-cards`)?.getBoundingClientRect(); return b && b.width ? b : null; }

  // A roll's production: each paying field sends its cards to the matching stack. All fields start together.
  flyPays(pays, wait) {
    const A = this.anim, B = this.game.board;
    for (const p of pays) {
      const n = Math.min(p.amt, 6);
      for (let i = 0; i < n; i++) {
        A.after(wait + A.ms(i * 80), () => {
          const to = this.stackRect(p.res), h = B.hexes[p.hex];
          if (!to || !h) return;
          const c = this.view.hexScreen(h);
          const w = to.width * 0.62;
          const from = { left: c.x - w / 2, top: c.y - w * 0.68 - 8 * c.s, width: w };
          A.fly(A.add(rcard(p.res), 'low'), from, to, 82, { dur: 480, lift: 46 * c.s, spin: (i % 2 ? 1 : -1) * 9 });
        });
      }
    }
  }

  // Cards leaving a resource stack: drawn out upward, then gone.
  liftRes(r, n, wait) {
    const A = this.anim;
    for (let i = 0; i < n; i++) {
      A.after(wait + A.ms(i * 70), () => {
        const from = this.stackRect(r);
        if (from) A.lift(A.add(rcard(r), 'low'), from, 82, { side: i % 2 ? 1 : -1 });
      });
    }
  }

  // A card that arrived is shown in its slot (it was held back while it was on its way).
  landCard(key) {
    if (!this.hideCards.delete(key)) return;
    const el = this.$hand.querySelector(`[data-tip="${key}"]`);
    if (el) el.style.visibility = '';
    this.anim.play(`new:${key}`, PULSE, { dur: 700 });
    this.anim.sync(this.$hand);
  }

  // A card bought in the shop (or kept from a pack) flies face up from its offer to its slot.
  flyBought(c, from) {
    const A = this.anim, it = ITEMS[c.id];
    const to = this.$hand.querySelector(`[data-tip="${c.key}"]`)?.getBoundingClientRect();
    if (!it || !to || !to.width || !from?.width) return this.landCard(c.key);
    A.fly(A.add(this.bigCard(it), 'low'), from, to, 176, { dur: 560, lift: 24, fadeIn: false }).then(() => this.landCard(c.key));
  }

  // Where a revealed card rests: the middle of the table that the action card and the hand leave free.
  revealSpot() {
    const s = this.$stage.getBoundingClientRect(), rc = this.$stage.querySelector('.rcol')?.getBoundingClientRect(), hh = this.$hand.getBoundingClientRect();
    const right = rc && rc.left - s.left > 320 ? rc.left : s.right;
    const bottom = hh.top - s.top > 240 ? hh.top : s.bottom;
    const h = Math.max(190, Math.min(340, (bottom - s.top) * 0.42)), w = (h * 176) / 246;
    return { left: (s.left + right) / 2 - w / 2, top: (s.top + bottom) / 2 - h / 2, width: w, height: h };
  }

  // Development cards drawn from the stack are revealed one after another.
  queueReveal(c, wait) {
    const at = performance.now() + wait, gen = this.anim.gen;
    const p = this.revealQ.then(() => this.revealCard(c, at, gen));
    this.revealQ = p.catch((e) => { console.error(e); if (c.key) this.landCard(c.key); });
    return p.catch(() => null);
  }

  // The table darkens, the card lies face down in the middle, turns over by itself and flies to the hand.
  // (A Victory Point card has no slot: it dissolves, and its point leaves from there.) Resolves with the card's centre.
  async revealCard(c, at, gen) {
    const A = this.anim, it = ITEMS[c.id];
    if (!A.on || !it) { if (c.key) this.landCard(c.key); return null; }
    await A.wait(Math.max(0, at - performance.now()), gen);
    const spot = this.revealSpot();
    const dim = A.add('', 'low');
    dim.className = 'fx-dim';
    const card = A.add(`<div class="fx-flip"><div class="fx-face back"><i></i></div><div class="fx-face front">${this.bigCard(it)}</div></div>`, 'low');
    A.dims++;
    try {
      const small = { left: spot.left + spot.width * 0.08, top: spot.top + spot.height * 0.14, width: spot.width * 0.84 };
      A.run(dim, [{ opacity: 0 }, { opacity: 1 }], { dur: 240, keep: true, gen });
      await A.run(card, [{ transform: A.place(card, small, 176), opacity: 0 }, { transform: A.place(card, spot, 176), opacity: 1 }], { dur: 300, ease: EASE_OUT, keep: true, gen });
      await A.wait(A.ms(320), gen);
      await A.run(card.firstElementChild, [
        { transform: 'perspective(900px) rotateY(0deg) scale(1)' },
        { transform: 'perspective(900px) rotateY(90deg) scale(1.08)', offset: 0.5 },
        { transform: 'perspective(900px) rotateY(180deg) scale(1)' },
      ], { dur: 520, ease: 'cubic-bezier(.45, 0, .3, 1)', keep: true, gen });
      await A.wait(A.ms(680), gen);
    } finally {
      A.dims = Math.max(0, A.dims - 1);
      A.run(dim, [{ opacity: 1 }, { opacity: 0 }], { dur: 340, gen });
    }
    const to = c.key ? this.$hand.querySelector(`[data-tip="${c.key}"]`)?.getBoundingClientRect() : null;
    if (to && to.width) await A.fly(card, spot, to, 176, { dur: 540, lift: 16, fadeIn: false, gen });
    else await A.lift(card, spot, 176, { gen });
    if (c.key) this.landCard(c.key);
    return { x: spot.left + spot.width / 2, y: spot.top + spot.height / 2 };
  }

  // Score orbs: one per point. Each one that reaches the counter raises it by one.
  sendOrbs(srcs, wait, seed0 = 0) {
    const A = this.anim, n = srcs.length;
    if (!n) return;
    const gap = Math.min(90, 720 / n);
    this.orbsOut = (this.orbsOut || 0) + n;
    srcs.forEach((fn, i) => A.after(wait + A.ms(i * gap), () => {
      const t = this.$hud.querySelector('[data-ck="vp"]')?.getBoundingClientRect();
      const f = fn();
      if (!t || !t.width || !f) return this.vpArrive();
      A.orb(f, { x: t.left + t.width / 2, y: t.top + t.height / 2 }, { seed: seed0 + i }).then(() => this.vpArrive());
    }));
  }
  vpArrive() {
    this.orbsOut = Math.max(0, (this.orbsOut || 0) - 1);
    const held = this.feel.holds.get('vp');
    if (held != null) {
      const to = this.game.vpBreakdown().total;
      this.feel.tick('vp', Math.min(to, held + 1), to);
    }
    if (!this.orbsOut) this.settleVp(); // whatever happened on the way, the counter ends on the true score
  }
  settleVp() {
    if (!this.feel.holds.has('vp')) return;
    this.feel.release('vp');
    const to = this.game.vpBreakdown().total;
    for (const n of document.querySelectorAll('[data-ck="vp"]')) n.textContent = to;
  }

  // An opened pack has turned all its cards over.
  packShown(m) { return !this.anim.on || performance.now() - (m.t0 ?? 0) > this.anim.ms(PACK_T.first + (m.options.length - 1) * PACK_T.gap + PACK_T.turn); }

  // Shop offers and pack picks lean toward the pointer while it is over them.
  tiltAt(ev) {
    const host = ev && this.anim.on ? ev.target.closest?.('.offer:not(.sold)') : null;
    const el = host ? host.querySelector('.o-stage > *') : null;
    if (this.tiltEl && this.tiltEl !== el) { this.tiltEl.style.transform = ''; this.tiltEl.style.transition = ''; this.tiltEl = null; }
    if (!el) return;
    const r = host.getBoundingClientRect();
    const lim = (v) => Math.max(-1, Math.min(1, v));
    const nx = lim((ev.clientX - (r.left + r.width / 2)) / (r.width / 2)), ny = lim((ev.clientY - (r.top + r.height / 2)) / (r.height / 2));
    el.style.transition = 'transform .09s ease-out';
    el.style.transform = `perspective(560px) translateY(-4px) rotateX(${(-ny * 9).toFixed(2)}deg) rotateY(${(nx * 12).toFixed(2)}deg) scale(1.03)`;
    this.tiltEl = el;
  }

  // ---------------------------------------------------------------- roll highlights
  // A roll's report gets `changes` when it resolves; that starts the highlight clock.
  syncHighlights() {
    const rep = this.game.report;
    const key = rep && rep.changes ? rep : null;
    if (key === this.hlReport) return;
    this.hlReport = key;
    const land = key ? this.landIn() : 0;
    this.hlStart = performance.now() + land; // pulses and +n badges wait for the dice to land
    this.hlMap = new Map();
    this.payout = null;
    if (!key) return;
    for (const c of key.changes) this.hlMap.set(c.key, c);
    // The payout lands when the dice do: cards drop in, VP counts up, and a big one shakes the table.
    this.payout = { start: this.hlStart, until: this.hlStart + 1800, land, fresh: true };
    const cards = RES.reduce((n, r) => n + Math.max(0, this.hlMap.get(`hand:${r}`)?.delta || 0), 0);
    const vpGain = Math.max(0, this.hlMap.get('vp')?.delta || 0);
    const level = cards >= 10 || vpGain >= 4 ? 2 : cards >= 6 || vpGain >= 2 ? 1 : 0;
    if (level) this.later(() => this.feel.hit(level, 'good'), land + 360);
    for (const f of key.fired || []) {
      this.hlMap.set(`face:${f.die}:${f.face}`, { key: '', badge: '!' });
      this.hlMap.set(`die:${f.die}`, { key: '', badge: '!' });
    }
  }

  // Pulses every element the latest roll changed or fired, with a +n badge. Runs after the hand renders.
  applyHighlights() {
    const el = performance.now() - this.hlStart;
    if (!this.hlMap.size || el > HL_MS) return;
    const hd = `${-Math.round(el)}ms`;
    for (const node of document.querySelectorAll('[data-hl]')) {
      const hit = node.dataset.hl.split(' ').map((k) => this.hlMap.get(k)).find(Boolean);
      if (!hit) continue;
      node.classList.add('hl');
      node.style.setProperty('--hd', hd);
      if (node.querySelector(':scope > .delta')) continue;
      const b = document.createElement('i');
      let text = hit.badge ?? (hit.key.startsWith('card:') ? 'New' : `${hit.delta > 0 ? '+' : ''}${hit.delta}`);
      if (hit.key === 'vp') text += ' VP';
      b.className = `delta${hit.badge ? ' bang' : ''}`;
      b.textContent = text;
      b.style.setProperty('--hd', hd);
      node.appendChild(b);
    }
  }

  // ---------------------------------------------------------------- detail cards (hover, or click to keep open)
  // Registers a detail card for an element; returns the attribute that opens it.
  tipAttr(key, info) {
    this.tips.set(key, info);
    return `data-tip="${esc(key)}"`;
  }

  setRoadHl(on) {
    if (!!this.hlRoad === on) return;
    this.hlRoad = on;
    this.renderBoard();
  }

  openTip(key, el) {
    if (this.game.phase === 'gameover') return; // the summary owns the screen
    this.setRoadHl(key === 'stat:road');
    this.tipKey = key;
    this.$tip.hidden = false;
    this.fillTip(key, el);
  }

  fillTip(key, el) {
    const info = this.tips.get(key);
    if (!info || !el) { this.hideTip(); return; }
    const pinned = this.pinnedTip === key;
    this.$tip.classList.toggle('pinned', pinned);
    this.$tip.innerHTML = `${info.fig ? `<div class="tip-fig">${[].concat(info.fig).map((f) => figure(f, 0.7)).join('')}</div>` : ''}<div class="tip-kind">${esc(info.kind)}</div><div class="tip-title">${esc(info.title)}</div>
      ${info.desc ? `<p>${esc(info.desc)}</p>` : ''}
      ${info.now ? `<div class="tip-now">${esc(info.now)}</div>` : ''}
      ${info.lines && info.lines.length ? `<ul>${info.lines.map((l) => `<li>${esc(l)}</li>`).join('')}</ul>` : ''}
      <div class="tip-hint">${pinned ? 'Click again to close' : 'Click to keep this open'}</div>`;
    const r = el.getBoundingClientRect();
    const w = this.$tip.offsetWidth;
    const h = this.$tip.offsetHeight;
    let top = r.top - h - 10;
    if (top < 8) top = r.bottom + 10;
    top = Math.max(8, Math.min(top, innerHeight - h - 8));
    const left = Math.max(8, Math.min(r.left + r.width / 2 - w / 2, innerWidth - w - 8));
    this.$tip.style.left = `${left}px`;
    this.$tip.style.top = `${top}px`;
  }

  hideTip() {
    this.setRoadHl(false);
    this.tipKey = null;
    this.$tip.hidden = true;
  }

  pinTip(key, el) { this.pinnedTip = key; this.openTip(key, el); }
  unpinTip() { this.pinnedTip = null; this.hideTip(); }

  // Keeps an open detail card in step with re-renders, or closes it when its element is gone.
  refreshTip() {
    if (!this.tipKey) return;
    const el = document.querySelector(`[data-tip="${CSS.escape(this.tipKey)}"]`);
    if (!el || !this.tips.has(this.tipKey) || this.game.phase === 'gameover') { this.pinnedTip = null; this.hideTip(); return; }
    this.fillTip(this.tipKey, el);
  }

  // ---------------------------------------------------------------- run card: ante, boss and tribute in one plaque
  // Where you are in the run: the ante, and which of its three rounds this is (a progress track, not a control).
  runHead() {
    const g = this.game;
    const shop = g.phase === 'shop';
    const cls = (i) => `${i < g.blind || (shop && i === g.blind) ? 'done' : i === g.blind ? 'on' : ''}${i === 2 ? ' boss' : ''}`;
    return `<div class="run-head"><b class="run-ante" data-ak="ante" title="Rounds survived this run: ${g.roundsSurvived}">Ante ${g.ante}</b><ol class="rounds" aria-label="Rounds of ante ${g.ante}">${BLINDS.map((b, i) => `<li class="${cls(i)}"${i === g.blind && !shop ? ' aria-current="step" data-ak="round-on round-dot"' : ''}>${b}</li>`).join('')}</ol></div>`;
  }

  // The boss of this ante (or the next one while you shop after a Boss round). It is quiet until its round, loud during it.
  bossRow() {
    const g = this.game;
    if (!g.boss) return '';
    const live = g.blind === 2 && g.phase !== 'shop';
    const next = g.phase === 'shop' && g.blind === 2;
    const boss = next ? BOSS_BY_ID[g.nextBossId] : g.boss;
    const label = live ? 'Boss · in effect this round' : next ? 'Boss of the next ante' : 'Boss · only in the Boss round';
    return `<div class="boss-row ${live ? 'live' : 'dormant'}" ${live ? 'data-ak="boss-live"' : ''} ${this.tipAttr('boss', { kind: live ? 'Boss · active' : 'Boss', title: boss.name, desc: boss.desc, lines: live ? [] : ['Applies in the Boss round only.'] })}><span class="eyebrow">${label}</span><div class="name">${boss.name}</div><p>${boss.desc}</p></div>`;
  }

  // The run card sits above the action card: ante and round, the boss, and what is due at the end of this round.
  renderTribute() {
    const g = this.game;
    const el = this.$tribute;
    if (g.phase === 'gameover' || !g.tribute) { el.hidden = true; return; }
    el.hidden = false;
    const boss = g.blind === 2 && g.phase !== 'shop';
    el.classList.toggle('boss', boss);
    if (g.phase === 'shop') {
      const st = this.stamp && performance.now() - this.stamp.start < 2600 ? this.stamp : null;
      const bossDown = g.blind === 2;
      el.innerHTML = `${this.runHead()}${this.bossRow()}<div class="trib"><div class="paid ${bossDown ? 'boss' : ''} ${st ? 'slam' : ''}" ${st ? `style="animation-delay:${-Math.round(performance.now() - st.start)}ms"` : ''}><b>Paid</b><span>${bossDown ? 'The boss is beaten.' : `${BLINDS[g.blind]} tribute handed over.`}</span></div></div>`;
      return;
    }
    const due = g.tributeDue();
    const assign = g.autoAssign();
    const ok = assign != null;
    const lines = [];
    const pcts = [];
    const parts = due.map((p, i) => {
      const t = p.type || (ok ? assign[i] : null);
      const base = g.tribute[i] ? g.tribute[i].amount : p.amount;
      const why = [`${base} base`];
      if (i === 0 && g.oldBootExtra) why.push(`+${g.oldBootExtra} The Old Boot (dead rolls)`);
      if (p.amount < base + (i === 0 ? g.oldBootExtra : 0)) why.push(`−${base + (i === 0 ? g.oldBootExtra : 0) - p.amount} reductions`);
      lines.push(`${p.type ? cap(p.type) : 'Any type'}: ${p.amount} (${why.join(' ')})`);
      const have = t ? g.available(t) : Math.max(...RES.map((r) => g.available(r)));
      const pct = Math.min(100, Math.round((Math.min(have, p.amount) / p.amount) * 100));
      pcts.push(pct);
      return `<div class="tpart" ${t ? `data-res="${t}"` : ''}><div class="t-row">${t ? resDot(t) : '<span class="res-dot any"></span>'}<span>${t ? cap(t) : 'Any type'}</span><span class="have">${Math.min(have, p.amount)}<span> / ${p.amount}</span></span></div><div class="bar ${pct >= 100 ? 'full' : ''}"><i data-ak="bar:${i}" style="width:${pct}%;--c:${t ? `var(--${t})` : 'var(--muted)'}"></i></div></div>`;
    }).join('');
    // Bars grow to their new length (after the dice have landed, when a roll filled them) instead of jumping.
    const barId = `${g.ante}:${g.blind}:${g.phase === 'setup'}`;
    const fresh = this.bars.id !== barId;
    const wait = this.landIn() + (this.rollNow ? this.anim.ms(420) : 0);
    pcts.forEach((pct, i) => {
      const old = fresh ? 0 : this.bars.pcts[i] ?? 0;
      if (pct !== old) this.anim.play(`bar:${i}`, [{ width: `${old}%` }, { width: `${pct}%` }], { dur: 520, wait: fresh ? this.anim.ms(260) : wait });
    });
    this.bars = { id: barId, pcts };
    // While you can still roll or build, a payable tribute is paid from here: the counter is where you see that it is ready.
    const step = this.step();
    const left = ROLLS_PER_ROUND - g.rollsUsed;
    const payHere = ok && g.phase === 'turn' && (step === 'roll' || step === 'build') && !this.modal && !this.boardReq;
    const state = g.phase === 'setup' ? ''
      : payHere ? `<button class="pay-now" data-a="end" ${this.busy ? 'disabled' : ''} title="End the round now and pay the tribute${left > 0 ? `. Each unused roll is worth 1 VP in the shop` : ''}">Pay now${left > 0 ? `<small>+${left} VP</small>` : ''}</button>`
        : ok ? '<b class="ok">Ready to pay</b>' : '<b class="no">Not yet</b>';
    el.innerHTML = `${this.runHead()}${this.bossRow()}<div class="trib" data-ak="trib"><div class="trib-head"><span class="eyebrow" ${this.tipAttr('tribute', { kind: 'Tribute', title: 'Due at round end', desc: 'Each part needs a different resource type. Storehouse cards count first, then your hand.', lines })}>Tribute · due at round end</span>${state}</div><div class="trib-parts">${parts}</div></div>`;
  }

  // The score: a big number at the far right of the hand row.
  vpBig() {
    const g = this.game;
    const vp = g.vpBreakdown();
    const info = { kind: 'Score', title: `${vp.total} VP`, desc: 'Your score this round. Whatever you hold when the tribute is paid becomes your shop budget.', lines: [`Settlements ${vp.settlements} · Cities ${vp.cities}`, `VP cards ${vp.vpCards}`, `Longest road ${vp.road} (length ${vp.longestRoad})`, `Army ${vp.army} (${g.knights} knights)`] };
    const digits = String(vp.total).length;
    return `<section class="zone vp-zone" data-hl="vp" ${this.tipAttr('score', info)}><div class="zone-h">Score</div><div class="vp-body d${Math.min(digits, 4)}"><div class="num"><span data-ck="vp">${this.feel.value('vp', vp.total)}</span><small>VP</small></div></div></section>`;
  }

  // Rolls left, shown inside the roll buttons.
  rollsLeft() {
    const left = ROLLS_PER_ROUND - this.game.rollsUsed;
    return `<span class="rl" title="Rolls left this round">${Array.from({ length: ROLLS_PER_ROUND }, (_, i) => `<i class="${i < left ? 'on' : ''}"></i>`).join('')}<b>${left} left</b></span>`;
  }

  // The ? button that opens the tips for the current step; it sits in the top right corner of the action card.
  tipBtn() {
    return this._tip ? `<button class="tip-btn ${this.tipsOpen ? 'on' : ''} ${this.tipsSeen ? '' : 'new'}" data-a="tips" aria-expanded="${this.tipsOpen}" title="How this step works" aria-label="How this step works">?</button>` : '';
  }

  // Top of the action card: the three steps of a round as a numbered line (progress, not buttons), and the ? for this step.
  actHead(step) {
    if (step === 'gameover') return '';
    let lead;
    if (step === 'shop') lead = '<span class="act-title">Shop<small>between rounds</small></span>';
    else if (step === 'pick') lead = '<span class="act-title">Upgrade<small>choose a face</small></span>';
    else {
      const current = step === 'adjust' || step === 'result' ? 'roll' : step;
      const idx = STEPS.findIndex(([k]) => k === current); // −1 during setup: the steps are a preview
      lead = `<ol class="steps" aria-label="Steps of a round">${STEPS.map(([, l], i) => `<li class="${i === idx ? 'on' : i < idx ? 'done' : ''}"${i === idx ? ' aria-current="step" data-ak="step-on"' : ''}><i${i === idx ? ' data-ak="step-dot"' : ''}>${i + 1}</i>${l}</li>`).join('')}</ol>`;
    }
    return `<div class="act-head">${lead}${this.tipBtn()}</div>`;
  }

  // Active round effects: [label, 'bad' | 'good' | '', tooltip]
  effects() {
    const g = this.game;
    if (g.phase !== 'turn' && g.phase !== 'tribute') return [];
    const fx = [];
    if (g.oldBootExtra) fx.push([`Old Boot +${g.oldBootExtra}`, 'bad', 'The Old Boot: every roll that produces nothing for you adds 1 to the tribute.', 'oldBoot']);
    if (g.bossIs('barbarians')) fx.push([`Fleet ${g.fleet}/3`, 'bad', 'Barbarian Fleet: each 7 or double advances it; at 3 a random building is hit. Knights push it back.', 'fleet']);
    if (g.chain > 0) fx.push([`Echo chain ${g.chain}`, 'good', `Echo: each double gives a free roll of that die. The chain breaks the game at ${ECHO_BREAK}.`, 'chain']);
    if (g.bribe) fx.push([`Bribe −${g.bribe}`, 'good', 'Bribe: the tribute is reduced.']);
    const cities = g.counts().city;
    if (g.hasGuild('taxCollector') && cities) fx.push([`Tax −${cities}`, 'good', 'Tax Collector: each city reduces the tribute by 1.']);
    if (g.levyDelay) fx.push(['Levy Delay', 'good', 'This round\'s tribute is pushed to the next round at +50%.']);
    if (g.monopoly) fx.push([`Monopoly: ${g.monopoly}`, 'good', 'All your production this round becomes this resource.']);
    if (g.bumper) fx.push(['Bumper ×2', 'good', 'Your next roll produces double.']);
    if (g.omen != null) fx.push([`Omen ${g.omen}`, 'good', 'If the next roll hits this number, production is tripled.']);
    if (g.fireSale) fx.push(['Fire Sale 2:1', 'good', 'Bank trades are 2:1 for the rest of the round.']);
    if (g.phase === 'turn' && g.rollsUsed > 0 && g.roundProduced === 0 && !g.streakGiven && this.step() !== 'result') fx.push([`Dry ${g.rollsUsed}/${ROLLS_PER_ROUND}`, '', `Losing streak: no resources from ${g.rollsUsed} roll(s) so far. If all ${ROLLS_PER_ROUND} rolls come up empty, you get a free development card.`]);
    if (g.brokeGame) fx.push(['Game broken!', 'good', 'Echo chain of 10: this round\'s tribute counts as paid.']);
    return fx;
  }

  // ---------------------------------------------------------------- board
  renderPrompt() {
    const b = this.boardReq;
    this.$prompt.hidden = !b;
    if (!b) return;
    const rep = this.replaceMap();
    this.$prompt.innerHTML = `<span><b>Click the board:</b> ${esc(b.prompt)}${rep ? ' <em class="rep-note">Hexes marked “Replaces …” lose their old effect.</em>' : ''}</span>${b.cancel ? '<button data-a="cancel-board">Cancel</button>' : ''}`;
  }

  // The longest unbroken chain of roads (same rule as the engine's longestRoad), with the edges in order.
  roadPath() {
    const g = this.game;
    const adj = new Map();
    for (const e of g.roads) for (const v of g.board.edges[e].v) { if (!adj.has(v)) adj.set(v, []); adj.get(v).push(e); }
    let best = [];
    const used = new Set();
    const path = [];
    const dfs = (v) => {
      if (path.length > best.length) best = [...path];
      for (const e of adj.get(v) || []) {
        if (used.has(e)) continue;
        used.add(e); path.push(e);
        const [a, b] = g.board.edges[e].v;
        dfs(a === v ? b : a);
        used.delete(e); path.pop();
      }
    };
    for (const v of adj.keys()) dfs(v);
    return { len: best.length, edges: best };
  }

  // Two small title cards next to the score: Longest road and Largest army, with what they are worth.
  statCards() {
    const g = this.game;
    const vp = g.vpBreakdown();
    const lr = vp.longestRoad;
    const kn = g.knights;
    const carto = g.hasGuild('cartographer');
    const marshal = g.hasGuild('marshal');
    const next = (n, base, guild) => (n < base ? `${base - n} more to reach ${base}` : guild ? `next VP at ${n + 1}` : `next VP at ${base + 2 * (Math.floor((n - base) / 2) + 1)}`);
    const roadInfo = {
      kind: 'Title · longest road',
      title: `${lr} road segment${lr === 1 ? '' : 's'} in a row`,
      desc: 'Your longest unbroken chain of roads. It starts to score at 5 segments, and the chain is shown numbered on the island while you hover this card.',
      lines: [
        '5 segments in a row: 2 VP',
        carto ? 'Cartographer: every segment beyond 5 gives +1 VP' : 'Every 2 further segments beyond 5: +1 VP',
        `Now: ${lr} segments = ${vp.road} VP${vp.road ? ` (2 base + ${vp.road - 2} extra)` : ''}`,
        `Next: ${next(lr, 5, carto)}`,
      ],
    };
    const armyInfo = {
      kind: 'Title · largest army',
      title: `${kn} knight${kn === 1 ? '' : 's'} played`,
      desc: 'Every Knight card you play counts toward your army, and it starts to score at 3 knights.',
      lines: [
        '3 knights played: 2 VP',
        marshal ? 'Marshal: every knight beyond 3 gives +1 VP' : 'Every 2 further knights beyond 3: +1 VP',
        `Now: ${kn} knights = ${vp.army} VP${vp.army ? ` (2 base + ${vp.army - 2} extra)` : ''}`,
        `Next: ${next(kn, 3, marshal)}`,
      ],
    };
    const card = (cls, label, n, goal, val, key, info, hl) => `<div class="stat ${cls} ${val ? 'on' : ''}" ${this.tipAttr(key, info)} ${hl ? 'data-hlroad="1"' : ''}><span class="s-k">${label}</span><span class="s-n">${n}</span><span class="s-v">${val ? `+${val} VP` : n >= goal ? '0 VP' : `${goal - n} to go`}</span></div>`;
    return `<section class="zone stat-zone"><div class="zone-h">Titles</div><div class="stats">${card('road', 'Road', lr, 5, vp.road, 'stat:road', roadInfo, true)}${card('army', 'Army', kn, 3, vp.army, 'stat:army', armyInfo, false)}</div></section>`;
  }

  // The upgrade being placed (from the engine's prompt), and which targets already carry an effect it would replace.
  replaceMap() {
    const b = this.boardReq;
    if (!b || b.kind !== 'hex') return null;
    const it = ITEM_LIST.find((x) => (x.cat === 'hex' || x.cat === 'token') && x.kind !== 'setter' && b.prompt.startsWith(`${x.name}:`));
    if (!it) return null;
    const m = new Map();
    for (const h of this.game.board.hexes) {
      const cur = it.cat === 'hex' ? h.hexEffect : h.tokenEffect;
      if (cur && b.ids.has(h.id)) m.set(h.id, ITEMS[cur.id].name);
    }
    return m.size ? m : null;
  }

  renderBoard() {
    const g = this.game;
    this.$board.classList.toggle('dimmed', g.phase === 'tribute' || g.phase === 'gameover');
    const resultStep = this.step() === 'result';
    const paid = resultStep ? new Set(g.report?.hexes || []) : new Set();
    const rolled = resultStep && g.report?.final && !g.report.final.zero ? g.report.final.sum : null;
    const B = g.board;
    this.view.render(g, {
      req: this.boardReq,
      paid,
      rolled,
      volcano: g.volcanoHex,
      boss: this.bossFx(),
      yields: (() => { const dist = this.sumDist(); const tot = dist.reduce((x, y) => x + y, 0) || 1; return (h) => ({ ...g.expectedYield(h), p: h.token ? dist[h.token] / tot : 0 }); })(),
      replace: this.replaceMap(),
      hlEdges: this.hlRoad ? this.roadPath().edges : null,
      tip: (h) => {
        const parts = [];
        if (h.hexEffect) parts.push(ITEMS[h.hexEffect.id]);
        if (h.tokenEffect) parts.push(ITEMS[h.tokenEffect.id]);
        if (!parts.length) return '';
        const it = parts[0];
        return this.tipAttr(`hx:${h.id}`, { kind: `${cap(h.terrain)} · ${parts.map((p) => CAT_LABEL[p.cat]).join(' + ')}`, title: parts.map((p) => p.name).join(' + '), desc: parts.map((p) => p.desc).join(' '), fig: parts.map((p) => p.id) });
      },
    });
    this.anim.sync(this.$board);
  }

  // Where the boss acts on the island: live in the Boss round, as a preview while its card is hovered before that.
  bossFx() {
    const g = this.game;
    if (!g.board || g.phase === 'setup' || g.phase === 'gameover') return null;
    const live = g.blind === 2 && g.phase !== 'shop';
    if (!live && !this.bossPreview) return null;
    const id = g.phase === 'shop' && g.blind === 2 ? g.nextBossId : g.bossId;
    const H = g.board.hexes;
    const fx = { id, live, blocked: new Set(), fog: new Set(), volcano: null, ports: false };
    if (id === 'doldrums') H.filter((h) => [2, 3, 11, 12].includes(h.token)).forEach((h) => fx.blocked.add(h.id));
    if (id === 'flood') H.filter((h) => h.token && h.token % 2 === 1).forEach((h) => fx.blocked.add(h.id));
    if (id === 'fog') (live && g.fogged ? g.fogged.map((f) => f.id) : g.bestHexes(3).map((h) => h.id)).forEach((x) => fx.fog.add(x));
    if (id === 'volcano') fx.volcano = live ? g.volcanoHex : g.bestHexes(1)[0]?.id ?? null;
    if (id === 'pirate') fx.ports = true;
    return fx;
  }

  // ---------------------------------------------------------------- step panel
  renderPanel() {
    const step = this.step();
    if (this.lastStep !== step) this.tipsOpen = false;
    this._tip = null;
    const pickingFace = this.modal?.type === 'face' && !this.benchOpen();
    const view = pickingFace ? this.viewPickFace() : {
      setup: () => this.viewSetup(),
      roll: () => this.viewRoll(),
      adjust: () => this.viewAdjust(),
      result: () => this.viewResult(),
      build: () => this.viewBuild(),
      tribute: () => this.viewTribute(),
      shop: () => this.viewShop(),
      gameover: () => ({ body: '' }), // shown as a summary over the board instead (renderOverlay)
    }[step]();
    if (!this._tip) this._tip = this.defaultTip(pickingFace ? 'pick' : step);
    if (this.boardReq) this._tip = { title: 'Choosing on the board', html: `<p>${esc(this.boardReq.prompt || 'Pick a spot on the board.')}</p><p>Marked spots are the legal choices. Drag the table to pan; Esc cancels when cancelling is allowed.</p>` };
    const scroll = this.$panel.querySelector('.panel-body')?.scrollTop || 0;
    const tips = this.tipsOpen && this._tip ? `<div class="tips-pop" role="dialog" aria-label="How this step works"><div class="eyebrow">${this._tip.title}</div><div class="tp-body">${this._tip.html}</div></div>` : '';
    const sec = view.sec || '';
    const footHtml = `${sec ? `<div class="foot-row">${sec}</div>` : ''}${view.foot || ''}`;
    this.$panel.hidden = step === 'gameover'; // the end of a run is shown as a summary over the board
    this.$panel.dataset.step = pickingFace ? 'pick' : step;
    this.$panel.innerHTML = `${this.actHead(pickingFace ? 'pick' : step)}${pickingFace ? '' : this.diceArea(step)}<div class="panel-body" data-ak="panel">${view.body}</div>${footHtml ? `<div class="panel-foot">${footHtml}</div>` : ''}${tips}`;
    if (this.lastStep === step) this.$panel.querySelector('.panel-body').scrollTop = scroll;
    for (const b of this.$panel.querySelectorAll('.panel-foot button.primary[data-primary]')) b.insertAdjacentHTML('beforeend', '<kbd>Space</kbd>');
    this.lastStep = step;
  }

  // The one place the dice live: both cubes, the roll's values, running effects, and a face sheet that opens on click.
  diceArea(step) {
    if (!['adjust', 'result'].includes(step)) return '';
    const g = this.game;
    let values = null, faces = null, opts = {};
    if (step === 'adjust') {
      const pr = g.pendingRoll;
      values = g.valuesOf(pr).v;
      faces = pr.faces;
      opts = { held: pr.hold.map((h) => h != null), notes: g.report?.dice.map((d) => d.notes) };
    } else if (step === 'result') {
      values = g.report.final.values;
      faces = g.lastRoll.faces;
      opts = { notes: g.report.dice.map((d) => d.notes) };
    } else if (g.lastRoll) faces = g.lastRoll.faces;
    const live = step === 'adjust' || step === 'result';
    const fx = this.effects();
    const fxHtml = fx.length ? `<div class="fx">${fx.map(([t, cls, tip, key]) => `<span class="fx-chip ${cls}" ${this.tipAttr(`fx:${t}`, { kind: 'Active this round', title: t, desc: tip })} data-hl="${key || ''}">${t}</span>`).join('')}</div>` : '';
    const dice = [0, 1].map((i) => {
      const held = opts.held && opts.held[i];
      const notes = opts.notes ? opts.notes[i] : [];
      const fi = faces ? faces[i] : 0;
      const face = g.dice[i].faces[fi];
      const shownNum = face.setter ? null : face.value;
      const diff = values && values[i] !== shownNum;
      return `<div class="die-box ${this.dieSheet === i ? 'open' : ''}" role="button" tabindex="0" data-a="die-sheet" data-die="${i}" title="Click to see this die's six faces">
        <div class="die-top">${this.cube(i, fi, held, live)}
          <div class="die-meta"><div class="die-lbl"><span>Die ${i + 1}${held ? ' · held' : ''}</span>${notes && notes.length ? `<span class="die-fx" ${this.tipAttr(`dfx:${i}`, { kind: `Die ${i + 1} · this roll`, title: notes.length === 1 ? '1 effect' : `${notes.length} effects`, lines: notes })} aria-label="${notes.length} effect${notes.length === 1 ? '' : 's'} on this die">${notes.slice(0, 5).map(() => '<i></i>').join('')}</span>` : ''}</div>${values ? `<div class="die-val ${diff ? 'changed' : ''}" title="${diff ? 'The face was changed by an upgrade' : ''}">${values[i] || 0}</div>` : ''}<span class="faces-hint">faces ▴</span></div></div>
      </div>`;
    }).join('<!--die-->');
    const fin = step === 'result' ? g.report.final : null;
    const total = fin ? (fin.zero ? 0 : fin.sum) : values ? (values[0] || 0) + (values[1] || 0) : null;
    const boxes = dice.split('<!--die-->');
    const sumHtml = total == null ? '' : `<i class="op">=</i><div class="die-total ${fin && fin.seven ? 'seven' : ''}"><div class="die-lbl"><span>Total</span></div><div class="die-val">${total}</div></div>`;
    return `<div class="dice-area">${fxHtml}<div class="dice2 sum">${boxes[0]}<i class="op">+</i>${boxes[1]}${sumHtml}</div>${this.dieSheet != null ? this.faceSheet(this.dieSheet) : ''}</div>`;
  }

  // Running round effects as chips.
  fxChips() {
    const fx = this.effects();
    return fx.length ? `<div class="fx">${fx.map(([t, cls, tip, key]) => `<span class="fx-chip ${cls}" ${this.tipAttr(`fx:${t}`, { kind: 'Active this round', title: t, desc: tip })} data-hl="${key || ''}">${t}</span>`).join('')}</div>` : '';
  }

  // The big dice shown in the Roll and Shop steps: no boxes, drag a die to spin it, click it for its six faces.
  diceStage(step) {
    const g = this.game;
    const fx = step === 'roll' ? this.effects() : [];
    const fxHtml = fx.length ? `<div class="fx">${fx.map(([t, cls, tip, key]) => `<span class="fx-chip ${cls}" ${this.tipAttr(`fx:${t}`, { kind: 'Active this round', title: t, desc: tip })} data-hl="${key || ''}">${t}</span>`).join('')}</div>` : '';
    const pick = step === 'pick';
    const dice = [0, 1].map((i) => pick
      ? `<div class="die-slot picking">${this.cube(i, 0, false, false, true)}<span class="die-cap">Die ${i + 1}</span></div>`
      : `<div class="die-slot ${this.dieSheet === i ? 'open' : ''}" data-a="die-sheet" data-die="${i}" title="Drag to spin · click for the six faces">${this.cube(i, g.lastRoll ? g.lastRoll.faces[i] : 0, false, false)}<span class="die-cap">Die ${i + 1}</span></div>`).join('');
    return `<div class="dice-stage ${pick ? 'choosing' : ''}">${fxHtml}<div class="ds-row">${dice}</div><div class="ds-hint">${pick ? 'Click a face to choose it' : 'Drag a die to spin it · click it for its faces'}</div>${!pick && this.dieSheet != null ? this.faceSheet(this.dieSheet) : ''}</div>`;
  }

  // All six faces of one die, with its upgrades. Opens above the dice on click.
  faceSheet(i) {
    const g = this.game;
    const shown = g.lastRoll ? g.lastRoll.faces[i] : null;
    return `<div class="die-sheet"><div class="ds-head"><span class="ds-tabs">${[0, 1].map((k) => `<button class="${k === i ? 'on' : ''}" data-a="die-open" data-die="${k}">Die ${k + 1}</button>`).join('')}</span><button class="small" data-a="die-close">Close</button></div>
      ${this.facesHtml(i, shown)}${this.dieTags(i)}
      ${this.rollNotes(i)}${this.oddsChart()}
      <p class="small muted">Hover a face for what it does${shown != null ? '. The outlined one showed last' : ''}. Face upgrades preview their effect on this curve when you place them.</p></div>`;
  }

  // A CSS 3D cube showing the die's six real faces, turned to face `fi`. Tumbles after each new roll.
  cube(i, fi, held, live, pick = false) {
    const d = this.game.dice[i];
    const SIDE = ['front', 'right', 'top', 'bottom', 'left', 'back']; // physical face k → cube side (opposites: 0-5, 1-4, 2-3)
    const TURN = { front: 'rotateX(0deg) rotateY(0deg)', right: 'rotateY(-90deg)', top: 'rotateX(-90deg)', bottom: 'rotateX(90deg)', left: 'rotateY(90deg)', back: 'rotateY(180deg)' };
    const PIPS = { 1: [5], 2: [1, 9], 3: [1, 5, 9], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
    const TONE = { front: '#e4dfd0', right: '#d6d0c0', top: '#efeadc', bottom: '#bdb7a7', left: '#d6d0c0', back: '#e4dfd0' };
    const PP = { 1: [[50, 50]], 2: [[28, 28], [72, 72]], 3: [[28, 28], [50, 50], [72, 72]], 4: [[28, 28], [72, 28], [28, 72], [72, 72]], 5: [[28, 28], [72, 28], [50, 50], [28, 72], [72, 72]], 6: [[28, 26], [72, 26], [28, 50], [72, 50], [28, 74], [72, 74]] };
    const SHADE = { front: '#cdc7b7', right: '#c4bead', top: '#cdc7b7', bottom: '#c4bead', left: '#bdb7a6', back: '#c4bead' };
    const u = (k) => `calc(var(--s, 56px) * ${k})`; // sizes scale with the cube
    const DARK = '#24262b'; // dark faces stay a shade above the panel so the die keeps its outline
    const pipBg = (v, ink) => PP[v].map((q) => `radial-gradient(circle at ${q[0]}% ${q[1]}%, ${ink} 0 ${u(0.09)}, transparent ${u(0.105)})`).join(', ');
    const sides = d.faces.map((f, k) => {
      const loaded = d.loaded && d.loaded.face === k;
      // The counted face lies on top and is the lightest; the sides fall off so it reads as the one that counts.
      const tone = pick ? (loaded ? '#e6cf8c' : TONE[SIDE[k]]) : k === fi ? (loaded ? '#ecd692' : '#f1ecde') : (loaded ? '#c9b271' : SHADE[SIDE[k]]);
      let bg = `${pipBg(f.value, '#17181b')}, ${tone}`;
      let inner = '';
      if (f.triggers.length && !f.setter) bg = `${svgUrl(faceBody(f.value, f.triggers))} center/100% 100% no-repeat, ${tone}`;
      if (f.setter === 'mirror') bg = `radial-gradient(circle at 50% 50%, ${DARK} 0 ${u(0.13)}, rgba(240, 234, 216, .45) ${u(0.17)}, ${tone} ${u(0.18)} ${u(0.27)}, rgba(240, 234, 216, .5) ${u(0.285)}, rgba(240, 234, 216, .12) ${u(0.36)}, ${DARK} ${u(0.45)})`;
      else if (f.setter === 'robber') { bg = DARK; inner = '<span class="lbl lt">R</span>'; }
      else if (f.setter === 'blank') { bg = DARK; inner = '<span class="lbl lt">?</span>'; }
      const faceTip = f.triggers.map((t) => ITEMS[t].name).join(', ') || (f.setter ? ITEMS[SETTER_ITEM[f.setter]].name : `Shows ${f.value}`);
      return `<div class="side ${SIDE[k]}" style="background:${bg}" ${pick ? `data-a="pick-face" data-die="${i}" data-face="${k}" title="Die ${i + 1}, face ${k + 1}: ${esc(faceTip)}"` : ''}>${inner}${f.triggers.length && extraTrg(f) ? `<span class="trg">${extraTrg(f)}</span>` : ''}</div>`;
    }).join('');
    const final = pick ? TURN[SIDE[fi]] : `rotateX(90deg) ${TURN[SIDE[fi]]}`; // the rolled face ends up on top
    let cls = '';
    const sp = this.spin[i];
    const spun = sp ? spunTransform(sp, pick) : '';
    let style = `--final:${final};transform:${spun}${final};`;
    const el = live ? this.rollElapsed() : null;
    const toss = el != null && !held ? ` toss" style="--td:${-Math.round(el)}ms` : '';
    if (el != null && !held) {
      const r = this.rollSpin[i];
      cls = 'rolling';
      style += `--rx0:${r[0]}deg;--ry0:${r[1]}deg;--rz0:${r[2]}deg;animation-delay:${-Math.round(el)}ms;`;
    }
    return `<div class="die3d ${held ? 'held' : ''}${toss}" data-hl="die:${i}" data-cube="${i}"><div class="tilt"><div class="cube ${cls}" style="${style}">${sides}</div></div></div>`;
  }

  // Milliseconds since the latest roll started, while its animation is still running (else null).
  rollElapsed() {
    const g = this.game;
    if (g.rollSeq !== this.seenSeq) {
      this.seenSeq = g.rollSeq;
      this.rollStart = performance.now();
      this.spin = [null, null];
      const spin = () => [720 + Math.floor(Math.random() * 360), 540 + Math.floor(Math.random() * 360), Math.floor(Math.random() * 180)];
      this.rollSpin = [spin(), spin()];
    }
    const el = performance.now() - (this.rollStart || 0);
    return g.rollSeq > 0 && el < this.anim.ms(900) ? el : null;
  }

  // Inline style that fades content in once the dice have landed.
  revealStyle(extra = 0) {
    const el = this.game.rollSeq === this.seenSeq ? performance.now() - (this.rollStart || 0) : 9999;
    const T = this.anim.ms(800);
    if (el > T + 400) return '';
    return `style="animation:reveal .3s ease both;animation-delay:${Math.round(T + extra - el)}ms"`;
  }

  facesHtml(i, shownFace) {
    const d = this.game.dice[i];
    return `<div class="faces">${d.faces.map((f, k) => {
      const loaded = d.loaded && d.loaded.face === k;
      return `<span class="face ${loaded ? 'loaded' : ''} ${shownFace === k ? 'shown' : ''}" ${this.tipAttr(`face:${i}:${k}`, this.faceInfo(i, k))} data-hl="face:${i}:${k}">${faceArt(f, loaded)}</span>`;
    }).join('')}</div>`;
  }

  // Triggers on a face as [id, count], so stacked copies show as ×2, ×3 …
  triggerCounts(face) {
    const counts = {};
    for (const t of face.triggers) counts[t] = (counts[t] || 0) + 1;
    return Object.entries(counts);
  }

  dieTags(i) {
    const g = this.game;
    const d = g.dice[i];
    const ups = g.dieUps(i);
    const lv = d.loaded ? d.loaded.level : 0;
    const meter = Array.from({ length: 10 }, (_, k) => `<i class="${k < lv ? 'on' : ''}"></i>`).join('');
    const loaded = d.loaded ? `<span class="tag loaded-tag" ${this.tipAttr(`load:${i}`, this.loadedInfo(i))} data-hl="loaded:${i}">Loaded Lvl. ${lv}<span class="lvl">${meter}</span></span>` : '';
    const upTags = ups.map((u) => `<span class="tag" ${this.tipAttr(`up:${i}:${u}`, this.upgradeInfo(i, u))}>${ITEMS[u].name}${d.used[u] ? ' (used)' : ''}${!d.upgrades.includes(u) ? ' (copied)' : ''}</span>`).join('');
    return `<div class="tags">${loaded}${upTags}</div>`;
  }

  // ---- detail-card content (what each element says when hovered or clicked)
  dieInfo(i) {
    const g = this.game;
    const d = g.dice[i];
    const ups = g.dieUps(i);
    const lines = ups.map((u) => `${ITEMS[u].name}${d.used[u] ? ' · used this round' : ''}${!d.upgrades.includes(u) ? ' · copied from the other die' : ''}`);
    if (d.loaded) lines.unshift(`Loaded to level ${d.loaded.level} of 10`);
    return {
      kind: 'Die',
      title: `Die ${i + 1}`,
      desc: 'Each roll shows one face of this die. Its six faces are listed under it, with their labels.',
      lines: lines.length ? lines : ['No upgrades yet.'],
    };
  }

  loadedInfo(i) {
    const d = this.game.dice[i];
    const lv = d.loaded.level;
    const [fav, opp, side] = LOADING[lv - 1];
    const sum = fav + opp + 4 * side;
    const pct = (x) => Math.round((x / sum) * 100);
    return {
      kind: 'Dice · Loaded',
      title: `Loaded, level ${lv} of 10`,
      desc: 'Buy Loaded again to raise the level. The favoured face gets more likely, and its opposite face too.',
      now: `Favoured face ${pct(fav)}% · opposite ${pct(opp)}% · each other face ${pct(side)}%`,
      lines: [lv < 10 ? `Next level costs ${LOADING[lv][3]} VP` : 'Maximum level reached'],
    };
  }

  upgradeInfo(i, u) {
    const d = this.game.dice[i];
    return {
      kind: 'Dice · upgrade',
      fig: u,
      title: ITEMS[u].name,
      desc: ITEMS[u].desc,
      now: d.used[u] ? 'Used this round.' : null,
      lines: [!d.upgrades.includes(u) ? 'Copied from the other die (Copycat).' : 'Bought for this die.'],
    };
  }

  faceInfo(i, k) {
    const g = this.game;
    const d = g.dice[i];
    const f = d.faces[k];
    const fired = (g.report?.fired || []).some((x) => x.die === i && x.face === k);
    const lines = this.triggerCounts(f).map(([t, n]) => `${ITEMS[t].name}${n > 1 ? ` ×${n}` : ''}: ${ITEMS[t].desc}`);
    const loaded = d.loaded && d.loaded.face === k;
    const nows = [];
    if (fired) nows.push('Fired on the last roll');
    if (loaded) nows.push(`Loaded face (level ${d.loaded.level})`);
    return {
      kind: `Die ${i + 1} · face ${k + 1}`,
      title: f.setter ? ITEMS[SETTER_ITEM[f.setter]].name : `Shows ${f.value}`,
      desc: f.setter ? ITEMS[SETTER_ITEM[f.setter]].desc : (lines.length ? '' : 'A plain face.'),
      now: nows.length ? nows.join(' · ') : null,
      lines,
    };
  }

  // What a guild is doing right now, for guilds whose effect grows with the run.
  guildNow(id) {
    const g = this.game;
    const vp = g.vpBreakdown();
    const cities = g.counts().city;
    const owned = g.ownedPorts();
    const gen = owned.filter((p) => p.type === 'generic').length;
    const spec = owned.length - gen;
    switch (id) {
      case 'taxCollector': return `Now: −${cities} from every tribute (${cities} ${cities === 1 ? 'city' : 'cities'})`;
      case 'twinFortune': return `Now: ${g.earned.twinFortune} VP earned from doubles this run`;
      case 'cartographer': return vp.longestRoad >= 5 ? `Now: +${vp.longestRoad - 5} VP from road segments beyond 5` : 'Now: needs a road of 5 to count';
      case 'marshal': return g.knights >= 3 ? `Now: +${g.knights - 3} VP from knights beyond 3` : 'Now: needs 3 knights to count';
      case 'moneylender': return `Now: ${gen} generic port${gen === 1 ? '' : 's'} give each specific port +${gen}`;
      case 'tradeConsul': return `Now: generic ports need ${spec} less input (${spec} specific port${spec === 1 ? '' : 's'})`;
      default: return null;
    }
  }

  // The how-to text, folded away once you know it. The choice is remembered.
  // How-to text no longer sits in the card: it is kept for the ? button in the card's header.
  // The big dice keep their size; the sheet opens below them and the card scrolls to it.
  revealSheet() {
    const sh = this.$panel.querySelector('.dice-stage .die-sheet');
    const body = sh?.closest('.panel-body');
    if (!sh || !body) return;
    const top = sh.offsetTop - body.offsetTop, need = top + sh.offsetHeight - body.clientHeight;
    if (need > body.scrollTop) body.scrollTo({ top: Math.min(need + 8, top - 8), behavior: 'smooth' });
  }

  // Light the hexes that produce the resource being pointed at, or the one picked in a trade or payment.
  applyResFocus() {
    const picked = document.querySelector('#panel [data-r].sel, #modal-root [data-r].sel, #hand .stack.sel[data-res]');
    const r = this.resHover || (picked && (picked.dataset.r || picked.dataset.res)) || null;
    const world = document.querySelector('#board .world');
    if (!world) return;
    // A clicked field shows the same: the hex, the buildings on it and what it pays (a resource being pointed at wins).
    const hx = r || this.boardReq ? null : this.hexFocus;
    const on = !!r || hx != null;
    world.classList.toggle('res-focus', on);
    for (const el of world.querySelectorAll('[data-hres], [data-hex]')) {
      const lit = r ? (el.dataset.hres || '').split(' ').includes(r)
        : hx != null ? (el.dataset.hx != null ? el.dataset.hx.split(' ').includes(String(hx)) : el.dataset.hex === String(hx)) : false;
      el.classList.toggle('res-lit', on && lit);
    }
  }

  // Steps without their own hint still get one, so the ? is always there.
  defaultTip(step) {
    const T = {
      setup: ['Setting up', '<p>Place your starting settlements, each with a road. Pick corners touching good numbers: 6 and 8 come up most, 2 and 12 least.</p><p>Each settlement pays one card from every hex it touches when setup ends.</p>'],
      adjust: ['Changing the roll', '<p>Your dice upgrades (Nudge, Recast and others) can change this roll before it pays out. Each can be used once per round.</p><p>Happy with the roll? Use it as it is.</p>'],
      result: ['Reading the result', '<p>The top line is the roll: die + die = total. Below it, every resource the roll gave or took, with the hexes it came from.</p><p><b>Also this roll</b> lists everything else that fired. Continue to build and trade.</p>'],
      pick: ['Choosing a face', '<p>Hover a face to preview how the upgrade changes it and how the chance of each total shifts. Click to apply.</p>'],
      shop: ['How the shop works', '<p>Spend VP on upgrades. Unspent VP is lost when you leave.</p>'],
      tribute: ['Paying the tribute', '<p>Each part needs its own resource type. Storehouse cards count first.</p>'],
      gameover: ['Run over', '<p>Start a new run or replay this seed.</p>'],
    };
    const t = T[step] || ['How this step works', '<p>Follow the main button at the bottom of the card.</p>'];
    return { title: t[0], html: t[1] };
  }

  hint(title, html) {
    this._tip = { title, html };
    return '';
  }

  // A titled group inside the action card: label, then its content, with one rhythm everywhere.
  blk(title, html, cls = '') {
    return `<section class="blk ${cls}"><h3>${title}</h3>${html}</section>`;
  }

  viewSetup() {
    const g = this.game;
    const n = Object.keys(g.buildings || {}).length;
    const roads = g.roads ? g.roads.size : 0;
    const road = n > roads;
    const dots = Array.from({ length: START_SETTLEMENTS }, (_, i) => `<i class="${i < roads ? 'done' : i === roads ? 'on' : ''}" data-ak="seg:${i}"></i>`).join('');
    return {
      body: `<h2>Set up your island</h2>
        <p class="lead">Place <b>${road ? 'a road' : `settlement ${n + 1} of ${START_SETTLEMENTS}`}</b> ${road ? 'next to the settlement you just placed.' : 'on one of the orange dots.'}</p>
        <div class="setup-prog">${dots}<span>${roads} of ${START_SETTLEMENTS} placed</span></div>
        ${this.blk('Picking a good spot', `<ul class="plain">
          <li>Each corner touches up to three hexes. A hex pays its resource when its number is rolled.</li>
          <li>More dots under a number means it is rolled more often. 6 and 8 are best.</li>
          <li>Touch different resources: the Boss tribute needs three different types.</li>
          <li>Each starting settlement gives you one card per hex next to it.</li></ul>`)}`,
      foot: this.tutorialButton(),
    };
  }

  // Probability of each sum 2–12 for the two dice as they are (or with one face swapped), as fractions.
  // Mirror faces copy the other die, a Blank face is counted as an even spread, the Robber's Face counts as a 7.
  sumDist(swap, load) {
    const g = this.game;
    const probs = [0, 1].map((i) => (load && load.die === i ? load.probs : g.faceProbs(i)));
    const faces = [0, 1].map((i) => g.dice[i].faces.map((f, k) => (swap && swap.die === i && swap.face === k ? swap.to : f)));
    const out = Array(13).fill(0);
    const vals = (f) => (f.setter === 'blank' ? [1, 2, 3, 4, 5, 6] : f.setter === 'mirror' ? ['m'] : [f.value]);
    for (let a = 0; a < 6; a++) for (let b = 0; b < 6; b++) {
      const pr = probs[0][a] * probs[1][b];
      const fa = faces[0][a], fb = faces[1][b];
      if (fa.setter === 'robber' || fb.setter === 'robber') { out[7] += pr; continue; }
      const va = vals(fa), vb = vals(fb);
      const w = pr / (va.length * vb.length);
      for (const x of va) for (const y of vb) {
        if (x === 'm' && y === 'm') continue; // two mirrors: the roll counts as 0
        out[(x === 'm' ? y : x) + (y === 'm' ? x : y)] += w;
      }
    }
    return out;
  }

  // The bell curve of the sum, before and (on hover) after the face change. Smooth path through the 11 points.
  curvePath(dist, W, H, top) {
    const pts = [];
    for (let s = 2; s <= 12; s++) pts.push([10 + ((s - 2) / 10) * (W - 20), H - 16 - (dist[s] / top) * (H - 30)]);
    let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
      const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
      d += ` C${c1[0].toFixed(1)} ${c1[1].toFixed(1)} ${c2[0].toFixed(1)} ${c2[1].toFixed(1)} ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
    }
    return { d, area: `${d} L${pts[10][0].toFixed(1)} ${H - 16} L${pts[0][0].toFixed(1)} ${H - 16} Z` };
  }

  distStats(dist) {
    const tot = dist.reduce((a, b) => a + b, 0) || 1;
    let mean = 0;
    for (let s = 2; s <= 12; s++) mean += (s * dist[s]) / tot;
    return { p7: dist[7] / tot, mean, tot };
  }

  // What a face upgrade does to the face, as a face object (or a list of them when the result is random).
  faceAfter(item, f) {
    if (item.id === 'reforge') return [1, 2, 3, 4, 5, 6].filter((v) => v !== f.value).map((v) => ({ ...f, value: v, setter: null }));
    if (item.id === 'raise') return [{ ...f, value: f.value === 6 ? 1 : f.value + 1, setter: null }];
    if (item.id === 'lower') return [{ ...f, value: f.value === 1 ? 6 : f.value - 1, setter: null }];
    const setter = { mirror: 'mirror', robberFace: 'robber', blank: 'blank' }[item.id];
    return setter ? [{ ...f, setter }] : null;
  }

  // What touched this die on the roll in front of you (Loaded, Nudge, Recast…), listed in its sheet.
  rollNotes(i) {
    const step = this.step();
    const notes = (step === 'adjust' || step === 'result') && this.game.report ? this.game.report.dice[i].notes : [];
    return notes.length ? `<div class="ds-notes"><h3>This roll</h3><ul>${notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul></div>` : '';
  }

  // The odds as the dice stand now (faces, Loaded weights, Mirror, Blank, Robber's Face): shown with a die's faces.
  oddsChart() {
    const W = 280, H = 104;
    const dist = this.sumDist();
    const st = this.distStats(dist);
    const top = Math.max(...dist) * 1.25 || 1;
    const cp = this.curvePath(dist, W, H, top);
    const x = (i) => (10 + (i / 10) * (W - 20)).toFixed(1);
    const best = Math.max(...dist.slice(2));
    const cols = Array.from({ length: 11 }, (_, i) => {
      const s = i + 2, pr = dist[s] / st.tot, y = H - 16 - (dist[s] / top) * (H - 30);
      return `<text x="${x(i)}" y="${(y - 6).toFixed(1)}" text-anchor="middle" class="pct ${dist[s] === best ? 'hi' : ''}">${pr ? (pr * 100 < 1 ? '<1' : Math.round(pr * 100)) : '–'}</text><text x="${x(i)}" y="${H - 3}" text-anchor="middle" class="${s === 7 ? 'seven' : ''}">${s}</text>`;
    }).join('');
    const none = 1 - st.tot;
    return `<div class="pk-chart odds" aria-label="Chance of each roll total with your dice as they are">
      <div class="pk-title">Chance of each total · %</div>
      <svg viewBox="0 0 ${W} ${H}" width="100%" role="img"><path d="${cp.area}" class="pk-before-fill"/><path d="${cp.d}" class="pk-before"/>${cols}</svg>
      <div class="pk-read">Both dice together: 7 comes up ${(st.p7 * 100).toFixed(1)}% · average total ${st.mean.toFixed(1)}${none > 0.0005 ? ` · no total ${(none * 100).toFixed(1)}%` : ''}.</div></div>`;
  }

  pickChart(item) {
    const g = this.game;
    const W = 280, H = 92;
    const before = this.sumDist();
    const after = {};
    let top = Math.max(...before);
    for (const d of [0, 1]) for (let k = 0; k < 6; k++) {
      const alts = this.faceAfter(item, g.dice[d].faces[k]);
      const dists = alts.map((to) => this.sumDist({ die: d, face: k, to }));
      const avg = before.map((_, s) => dists.reduce((a, x) => a + x[s], 0) / dists.length);
      after[`${d}-${k}`] = { dist: avg, random: alts.length > 1 };
      top = Math.max(top, ...avg);
    }
    top *= 1.1;
    this._pick = { before, after, top, W, H };
    const bp = this.curvePath(before, W, H, top);
    const ticks = Array.from({ length: 11 }, (_, i) => `<text x="${(10 + (i / 10) * (W - 20)).toFixed(1)}" y="${H - 3}" text-anchor="middle" class="${i + 2 === 7 ? 'seven' : ''}">${i + 2}</text>`).join('');
    const st = this.distStats(before);
    return `<div class="pk-chart" aria-label="Chance of each roll total">
      <div class="pk-title">Chance of each total</div>
      <svg viewBox="0 0 ${W} ${H}" width="100%" role="img"><path d="${bp.area}" class="pk-before-fill"/><path id="pk-after-fill" class="pk-after-fill" d=""/><path d="${bp.d}" class="pk-before"/><path id="pk-after" class="pk-after" d=""/>${ticks}</svg>
      <div id="pk-read" class="pk-read">Now: 7 comes up ${(st.p7 * 100).toFixed(1)}% · average total ${st.mean.toFixed(1)}. Hover a face to preview the change.</div></div>`;
  }

  pickPreview(key) {
    const c = this._pick;
    const path = document.querySelector('#pk-after');
    if (!c || !path) return;
    const fill = document.querySelector('#pk-after-fill');
    const read = document.querySelector('#pk-read');
    const bs = this.distStats(c.before);
    if (!key && this.modal?.type === 'load' && this.modal.sel) key = `${this.modal.sel.die}-${this.modal.sel.face}`;
    const a = key ? c.after[key] : null;
    if (!a) {
      path.setAttribute('d', ''); fill.setAttribute('d', '');
      read.textContent = `Now: 7 comes up ${(bs.p7 * 100).toFixed(1)}% · average total ${bs.mean.toFixed(1)}. Hover a face to preview the change.`;
      return;
    }
    const p = this.curvePath(a.dist, c.W, c.H, c.top);
    path.setAttribute('d', p.d); fill.setAttribute('d', p.area);
    path.classList.toggle('random', a.random);
    const as = this.distStats(a.dist);
    read.textContent = `${a.random ? 'Expected (the new value is random): ' : 'After: '}7 comes up ${(as.p7 * 100).toFixed(1)}% (now ${(bs.p7 * 100).toFixed(1)}%) · average total ${as.mean.toFixed(1)} (now ${bs.mean.toFixed(1)}).`;
  }

  benchOpen() { return this.game?.phase === 'shop' && ['face', 'load', 'die'].includes(this.modal?.type); }

  // The odds with a load placed on a face (Loaded: a new load, or the next level of an existing one).
  loadChart(m) {
    const g = this.game;
    const W = 320, H = 104;
    const before = this.sumDist();
    const after = {};
    let top = Math.max(...before);
    for (const o of m.options) {
      if (o.disabled) continue;
      const L = g.dice[o.die].loaded;
      const lv = L ? L.level + 1 : 1;
      for (let k = 0; k < 6; k++) {
        const face = L ? L.face : k;
        const [fav, opp, side] = LOADING[lv - 1];
        const probs = [0, 1, 2, 3, 4, 5].map((j) => (j === face ? fav : j === 5 - face ? opp : side));
        const dist = this.sumDist(null, { die: o.die, probs });
        after[`${o.die}-${k}`] = { dist, random: false };
        top = Math.max(top, ...dist);
      }
    }
    top *= 1.1;
    this._pick = { before, after, top, W, H };
    return this.chartShell(before, top, W, H);
  }

  chartShell(before, top, W, H) {
    const bp = this.curvePath(before, W, H, top);
    const ticks = Array.from({ length: 11 }, (_, i) => `<text x="${(10 + (i / 10) * (W - 20)).toFixed(1)}" y="${H - 3}" text-anchor="middle" class="${i + 2 === 7 ? 'seven' : ''}">${i + 2}</text>`).join('');
    const st = this.distStats(before);
    return `<div class="pk-chart" aria-label="Chance of each roll total">
      <div class="pk-title">Chance of each total · now and after</div>
      <svg viewBox="0 0 ${W} ${H}" width="100%" role="img"><path d="${bp.area}" class="pk-before-fill"/><path id="pk-after-fill" class="pk-after-fill" d=""/><path d="${bp.d}" class="pk-before"/><path id="pk-after" class="pk-after" d=""/>${ticks}</svg>
      <div id="pk-read" class="pk-read">Now: 7 comes up ${(st.p7 * 100).toFixed(1)}% · average total ${st.mean.toFixed(1)}. Hover a face to preview the change.</div></div>`;
  }

  // The workbench over the shop: both dice large, the odds beside them, and the one choice the upgrade needs.
  viewBench() {
    const g = this.game, m = this.modal;
    const name = m.prompt.split(':')[0];
    const item = ITEM_LIST.find((x) => x.name === name);
    const mode = m.type;
    const lead = mode === 'face' ? 'Drag a die to turn it. Hover a face to preview the odds, click it to apply.'
      : mode === 'load' ? 'Pick the face to favour, check the odds, then confirm. A loaded die raises its level on the face it already favours.'
        : 'Click the die that gets the upgrade.';
    const dice = [0, 1].map((i) => {
      const o = mode === 'face' ? null : m.options.find((x) => (mode === 'load' ? x.die : x.value) === i);
      const off = o && o.disabled;
      let cap = `Die ${i + 1}`;
      if (mode === 'load') {
        const L = g.dice[i].loaded;
        cap = `<b>Die ${i + 1}</b><span>${L ? `Lvl. ${L.level} → ${L.level + 1}` : 'Not loaded yet'} · ${o.cost === Infinity ? 'max level' : `${o.cost} VP`}</span>`;
      } else if (mode === 'die') cap = `<b>Die ${i + 1}</b><span>${off ? 'Already has it' : 'Click to choose'}</span>`;
      const cube = this.cube(i, 0, false, false, mode !== 'die' && !off);
      return mode === 'die'
        ? `<div class="die-slot bench-die ${off ? 'off' : ''}" ${off ? '' : `data-a="bench-die" data-die="${i}" role="button" tabindex="0"`}>${cube}<span class="die-cap">${cap}</span></div>`
        : `<div class="die-slot picking ${off ? 'off' : ''}">${cube}<span class="die-cap">${cap}</span></div>`;
    }).join('');
    const chart = mode === 'load' ? this.loadChart(m) : mode === 'face' && item && item.kind === 'setter' ? this.pickChart(item) : '';
    const sel = m.sel;
    const so = sel && m.options.find((x) => x.die === sel.die);
    const confirm = mode === 'load' ? `<button class="primary" data-a="load-confirm" ${sel ? '' : 'disabled'}>${sel ? `Load Die ${sel.die + 1} on face ${sel.face + 1} · ${so.cost} VP` : 'Pick a face first'}</button>` : '';
    return `<div class="bench" role="dialog" aria-label="${esc(name)}">
      <div class="bench-head"><div><div class="eyebrow">Shop · apply your upgrade</div><h2>${esc(name)}</h2></div>${item ? `<p>${esc(item.desc)}</p>` : ''}</div>
      <div class="bench-main"><div class="dice-stage choosing bench-dice"><div class="ds-row">${dice}</div><div class="ds-hint">${lead}</div></div>${chart ? `<div class="bench-odds">${chart}</div>` : ''}</div>
      <div class="bench-foot">${m.cancel ? '<button data-a="cancel-modal">Cancel</button>' : ''}${confirm}</div></div>`;
  }

  afterBench() {
    const m = this.modal;
    if (m?.type !== 'load' || !m.sel) return;
    const L = this.game.dice[m.sel.die].loaded;
    for (const el of this.$overlay.querySelectorAll(`.side[data-die="${m.sel.die}"]`)) el.classList.toggle('sel', Number(el.dataset.face) === (L ? L.face : m.sel.face));
    this.pickPreview(null);
  }

  // Choosing the face of a face upgrade: spin the dice in the action card and click the face itself.
  viewPickFace() {
    const m = this.modal;
    const item = ITEM_LIST.find((x) => x.cat === 'face' && x.kind === 'setter' && m.prompt.startsWith(`${x.name}:`));
    const name = m.prompt.split(':')[0];
    return {
      body: `<h2>${esc(name)}</h2>
        <p class="lead">Drag a die to turn it, then click the face to upgrade.</p>
        ${this.diceStage('pick', m)}
        ${item ? this.pickChart(item) : ''}`,
      foot: m.cancel ? '<button class="big center" data-a="cancel-modal">Cancel</button>' : '',
    };
  }

  viewRoll() {
    const g = this.game;
    const pre = g.cards.filter((c) => PRE_ROLL_CARDS.includes(c.id));
    return {
      body: `<h2>Your dice</h2>
        ${this.diceStage('roll')}
        ${this.hint('How a round works', `You have <b>${ROLLS_PER_ROUND} rolls</b>. Each roll pays every hex with that number to your buildings next to it (settlement 1, city 2). Between rolls you can build and trade. At the end you pay the tribute shown on the run card above.`)}
        ${pre.length ? `<div class="callout"><b>Before rolling:</b> you can play ${pre.map((c) => ITEMS[c.id].name).join(', ')} from your hand below.</div>` : ''}`,
      foot: `<button class="primary big" data-a="roll" data-primary ${this.busy ? 'disabled' : ''}>Roll the dice${this.rollsLeft()}</button>`,
      sec: this.tutorialOffered() ? this.tutorialButton() : '',
    };
  }

  viewAdjust() {
    const g = this.game;
    const pr = g.pendingRoll;
    const { v } = g.valuesOf(pr);
    const mods = g.modifiersAvailable();
    return {
      body: `<h2>Change the roll?</h2>
        <p class="lead">${mods.length ? 'Your dice upgrades can change this roll before it pays out.' : 'Nothing left to change. Use this roll when you are ready.'}</p>
        ${mods.length ? this.blk('Change the roll · optional', `<div class="tiles one">${mods.map((m) => `<button class="tile-btn ok" data-a="mod" data-die="${m.die}" data-id="${m.id}" ${this.busy ? 'disabled' : ''}><span class="t-name">${MOD_INFO[m.id][0]}<small>Die ${m.die + 1}</small></span><span class="t-desc">${MOD_INFO[m.id][1]}</span></button>`).join('')}</div>`) : ''}`,
      foot: `<button class="primary big" data-a="resolve" data-primary ${this.busy ? 'disabled' : ''}>Use this roll (${v[0] + v[1] || '?'})</button>`,
    };
  }

  viewResult() {
    const g = this.game;
    const rep = g.report;
    const f = rep.final;
    const gains = RES.filter((r) => rep.gains[r] > 0);
    const losses = RES.filter((r) => rep.gains[r] < 0);
    const store = RES.filter((r) => rep.storeGains[r] !== 0);
    const lines = rep.lines.filter((l) => l.cls !== 'roll');
    // Stacks and resources are shown under "You got"; this strip lists what else grew, fired or appeared.
    const fired = (rep.fired || []).map((f) => {
      const face = g.dice[f.die].faces[f.face];
      const names = face.setter ? [ITEMS[SETTER_ITEM[face.setter]].name] : this.triggerCounts(face).map(([t, n]) => `${ITEMS[t].name}${n > 1 ? ` ×${n}` : ''}`);
      return { cls: 'good', text: `Die ${f.die + 1} triggered: ${names.join(', ')}` };
    }).filter((c) => !c.text.endsWith(': '));
    const changes = [...fired, ...(rep.changes || []).filter((c) => c.delta !== 0 && !/^(hand|store):/.test(c.key))];
    const tags = [];
    if (f.zero) tags.push('<span class="pill bad">Mirror vs Mirror · counts as 0</span>');
    if (f.robberFace) tags.push('<span class="pill bad">Robber\'s Face · counts as 7</span>');
    else if (f.seven) tags.push('<span class="pill bad">7 · the robber strikes</span>');
    if (f.isDouble) tags.push('<span class="pill">Double</span>');
    if (rep.echo) tags.push('<span class="pill">Echo roll</span>');
    // Production lines say where each resource came from ("forest (5) → +2 lumber"); fold them into the rows.
    const src = {}, other = [], monoRows = {};
    for (const l of lines) {
      const m = /^(.+?) \((\d+|—)\) → \+(\d+) (\w+)(.*)$/.exec(l.msg);
      const mono = m && /monopoly from (\w+)/.exec(m[5]);
      if (m && RES.includes(m[4])) (src[m[4]] ||= []).push(`${cap(m[1])} ${m[2]}${m[5].includes('sister') ? ' (sister)' : ''}${Number(m[3]) > 1 ? ` ×${m[3]}` : ''}${mono ? ` (${cap(mono[1])})` : ''}`);
      if (mono) monoRows[m[4]] = true;
      if (!(m && RES.includes(m[4]))) other.push(l);
    }
    const row = (r, n, cls, from) => `<li data-res="${r}" class="got-row ${cls}${monoRows[r] && n > 0 ? ' mono' : ''}">${rcard(r, 'sm', '')}<span class="gr-main"><b>${cap(r)}${monoRows[r] && n > 0 ? '<em class="conv">Monopoly</em>' : ''}</b><small>${esc(from)}</small></span><span class="gr-n">${n > 0 ? '+' : '−'}${Math.abs(n)}</span></li>`;
    const rows = [
      ...gains.map((r) => row(r, rep.gains[r], 'good', (src[r] || []).join(' · ') || 'To your hand')),
      ...losses.map((r) => row(r, rep.gains[r], 'bad', f.seven ? 'Lost to the robber' : 'Left your hand')),
      ...store.map((r) => row(r, rep.storeGains[r], rep.storeGains[r] > 0 ? 'good' : 'bad', 'Storehouse')),
    ].join('');
    const net = gains.reduce((a, r) => a + rep.gains[r], 0);
    const nothingWhy = f.zero ? 'Two Mirror faces met, so the roll counts as 0.'
      : f.seven ? 'A 7 pays nothing.'
        : `No hex with a ${f.sum} touches your buildings${g.board.hexes.some((h) => h.token === f.sum && h.id === g.robber) ? ', or the robber blocks it' : ''}.`;
    const dry = g.roundProduced === 0 && !g.streakGiven;
    const empty = `<div class="got-none"><b>Nothing this time</b><span>${nothingWhy}</span>${dry ? `<span class="dry"><span class="dry-dots">${Array.from({ length: ROLLS_PER_ROUND }, (_, k) => `<i class="${k < g.rollsUsed ? 'on' : ''}"></i>`).join('')}</span>${g.rollsUsed} of ${ROLLS_PER_ROUND} dry rolls · all ${ROLLS_PER_ROUND} dry gives a free development card</span>` : ''}</div>`;
    const also = [...changes.map((c) => `<li class="${c.cls}">${esc(c.text)}</li>`), ...other.map((l) => `<li class="${l.cls}">${esc(cap(l.msg))}</li>`)].join('');
    const echoNext = g.echoQueue.length > 0;
    return {
      body: `${tags.length ? `<div class="res-tags" ${this.revealStyle()}>${tags.join('')}</div>` : ''}
        <div class="blks" ${this.revealStyle(120)}>
        <section class="blk got"><h3><span>${!gains.length && losses.length ? 'You lost' : 'You got'}</span>${net > 0 ? `<span class="got-sum">${net} card${net === 1 ? '' : 's'}</span>` : ''}</h3>${rows ? `<ul class="got-list">${rows}</ul>` : empty}</section>
        ${also ? `<section class="blk"><h3>Also this roll</h3><ul class="also">${also}</ul></section>` : ''}
        </div>`,
      foot: `<button class="primary big" data-a="seen" data-primary>${echoNext ? 'Continue · free Echo roll waiting' : 'Continue to build & trade'}</button>`,
    };
  }

  viewBuild() {
    const g = this.game;
    const dis = this.busy;
    const rollsLeft = ROLLS_PER_ROUND - g.rollsUsed;
    const echo = g.echoQueue.length > 0;
    const c = g.counts();
    const pipRow = (cost) => `<span class="cost">${RES.flatMap((r) => Array.from({ length: cost[r] || 0 }, (_, i) => `<span class="pip ${g.hand[r] > i ? '' : 'missing'}" style="background:var(--${r})" title="${cap(r)}"></span>`)).join('')}</span>`;
    // Each tile: name and how many you have, the cost as dots (hollow = missing), then one short line of status.
    const tile = (kind, name, effect, count = '') => {
      const why = g.whyNot(kind);
      const short = why ? why.split(/[:(]/)[0].trim() : '';
      return `<button class="tile-btn ${why ? '' : 'ok'}" data-a="build" data-kind="${kind}" data-cost="${kind}" ${why ? `title="${esc(why)}"` : ''} ${why || dis ? 'disabled' : ''}>
        <span class="t-name">${name}${count ? `<small>${count}</small>` : ''}</span>${pipRow(COSTS[kind])}
        <span class="${why ? 't-why' : 't-desc'}">${why ? esc(short) : effect}</span></button>`;
    };
    // trade
    const give = this.tradeGive;
    const rate = (r) => g.tradeRate(r);
    const giveRow = RES.map((r) => `<button class="rtile ${give === r ? 'sel' : ''}" data-a="give" data-r="${r}" ${g.hand[r] >= rate(r) && !dis ? '' : 'disabled'} title="Give ${rate(r)} ${r}"><span class="sw" style="background:var(--${r})"></span>${cap(r)}<b>${rate(r)}:1</b></button>`).join('');
    const getRow = RES.map((r) => `<button class="rtile" data-a="get" data-r="${r}" ${give && give !== r && !dis ? '' : 'disabled'} title="Get 1 ${r}"><span class="sw" style="background:var(--${r})"></span>${cap(r)}</button>`).join('');
    const tradeHint = !RES.some((r) => g.hand[r] >= rate(r))
      ? `You need ${Math.min(...RES.map(rate))} of one resource to trade.`
      : give ? `Giving ${rate(give)} ${give}. Now pick what you get.` : 'Pick what you give, then what you get.';
    // ship
    const ports = g.ownedPorts();
    let ship;
    if (g.bossIs('pirate')) ship = '<p class="cap bad">The Pirate: no shipping this round.</p>';
    else if (!ports.length) ship = '<p class="cap">Needs a port: build on a 3:1 or 2:1 corner of the coast.</p>';
    else {
      ship = ports.map((port) => {
        const { input, bonus } = g.storehouseRate(port);
        const rs = port.type === 'generic' ? RES : [port.type];
        return `<div class="port-row"><span class="pr-h"><b>${port.type === 'generic' ? 'Any-resource port' : `${cap(port.type)} port`}</b><span>ship ${input}, counts as ${input + bonus}</span></span>
          <div class="row">${rs.map((r) => `<button class="small" data-a="ship" data-port="${port.id}" data-r="${r}" data-mode="batch" ${g.hand[r] >= input && !dis ? '' : 'disabled'}>${resDot(r)} ${input} ${cap(r)}</button>${port.up.overflow ? `<button class="small" data-a="ship" data-port="${port.id}" data-r="${r}" data-mode="overflow" ${g.hand[r] > 0 && g.hand[r] < input ? '' : 'disabled'}>Leftover ${r}</button>` : ''}`).join('')}
          ${port.up.free ? `<button class="small" data-a="ship-mixed" data-port="${port.id}">Mixed batch</button>` : ''}</div></div>`;
      }).join('');
    }
    const primary = echo
      ? `<button class="primary big" data-a="roll" data-primary ${dis ? 'disabled' : ''}>Free Echo roll (die ${g.echoQueue[0] + 1})</button>`
      : rollsLeft > 0
        ? `<button class="primary big" data-a="roll" data-primary ${dis ? 'disabled' : ''}>Roll again${this.rollsLeft()}</button>`
        : `<button class="primary big" data-a="end" data-primary ${dis ? 'disabled' : ''}>Go to the tribute</button>`;
    const secondary = ''; // ending the round early now lives on the tribute counter (Pay now)
    const fx = this.fxChips();
    return {
      body: `${fx}${this.hint('How building and trading work', `<p>${g.rollsUsed === 0 ? 'Before your first roll.' : `After roll ${g.rollsUsed} of ${ROLLS_PER_ROUND}.`} Do as much as you like between rolls. Hover an option to see the cards it uses. The run card above says whether you can pay the tribute now; anything you build comes out of the rest.</p><p><b>Trade</b> gives you one card of any type for ${Math.min(...RES.map(rate))} of another (less with ports). <b>Ship</b> sends cards to the Storehouse from a port; they count toward the tribute with a bonus.</p>`)}
        ${this.blk('Build', `<div class="tiles">
          ${tile('settlement', 'Settlement', '+1 VP · pays 1 card', `${c.settlement}/${g.limits.settlement}`)}
          ${tile('city', 'City', '+1 VP · pays 2 cards', `${c.city}/${g.limits.city}`)}
          ${tile('road', 'Road', 'Reaches new corners', `${c.road}/${g.limits.road}`)}
          ${tile('dev', 'Development card', 'A random card for your hand')}
        </div>`)}
        ${this.blk('Trade with the bank', `<div class="trade-line"><span>Give</span><div class="trade-grid">${giveRow}</div></div>
          <div class="trade-line"><span>Get 1</span><div class="trade-grid">${getRow}</div></div>
          <p class="cap">${tradeHint}</p>`)}
        ${this.blk('Ship to the Storehouse', ship)}`,
      foot: primary,
      sec: secondary,
    };
  }

  viewTribute() {
    const g = this.game;
    const due = g.tributeDue();
    if (!this.tributeTypes || this.tributeTypes.length !== due.length) this.tributeTypes = g.autoAssign() ?? due.map((p) => p.type);
    const types = this.tributeTypes;
    const check = g.checkAssignment(types);
    const canAny = g.autoAssign() != null;
    const label = (p, i) => (p.fixed ? `${cap(p.type)} · fixed by the boss` : due.length > 1 ? `Part ${i + 1} of ${due.length} · pay with` : 'Pay with');
    return {
      body: `<h2>Pay the tribute</h2>
        ${this.hint('How paying works', `${due.length > 1 ? 'Each part needs a different resource type. ' : ''}Storehouse cards are used first, then your hand. The best choice is pre-selected.`)}
        ${due.map((p, i) => `<div class="tribute-part"><div class="tp-head"><span class="big-n">${p.amount}</span><span class="tp-of">${label(p, i)}${p.carried ? '<small>carried over by Levy Delay</small>' : ''}</span></div>
          ${p.fixed ? '' : `<div class="choice-row">${RES.map((r) => `<button class="${types[i] === r ? 'sel' : ''}" data-a="tpick" data-i="${i}" data-r="${r}" ${g.available(r) >= p.amount ? '' : 'disabled'} title="You have ${g.available(r)} ${r}">${resDot(r)}${cap(r)}<span>${g.available(r)}</span></button>`).join('')}</div>`}</div>`).join('')}
        ${!check.ok && canAny ? `<div class="callout bad">${esc(check.msg)}</div>` : ''}
        ${!canAny ? '<div class="callout bad"><b>You can\'t pay this tribute.</b> The run ends here.</div>' : ''}`,
      foot: canAny
        ? `<button class="primary big" data-a="pay" data-primary ${check.ok ? '' : 'disabled'}>Pay tribute</button>`
        : '<button class="primary big" data-a="fail" data-primary>End the run</button>',
    };
  }

  // The shop itself is a popup over the board; the action card keeps the button for the next round in its usual place.
  viewShop() {
    const g = this.game;
    const next = g.blind === 2 ? `ante ${g.ante + 1}, Small round` : `${BLINDS[g.blind + 1]} round`;
    const nextBoss = g.blind === 2 ? BOSS_BY_ID[g.nextBossId] : g.boss;
    return {
      body: `${this.hint('How the shop works', 'Spend your VP on upgrades in the shop window. Unspent VP is lost when you leave; buying never lowers your score.')}
        <h2>Your dice</h2>
        <p class="lead">Dice upgrades land here. <b>${g.budget} VP</b> left to spend.</p>
        ${this.diceStage('shop')}`,
      foot: `<button class="primary big" data-a="leave" data-primary ${this.busy ? 'disabled' : ''}>Next: ${next}</button>`,
      sec: `<button class="small ghost" data-a="reroll-boss" ${g.budget >= g.bossRerollPrice ? '' : 'disabled'} title="Replace ${esc(nextBoss.name)} with another boss">Reroll boss · ${g.bossRerollPrice} VP</button>`,
    };
  }

  // One thing you can take, drawn the same way in the shop and when a pack is opened:
  // upgrades show the object they change, cards show the card itself.
  offerArt(it) {
    const desc = `${it.desc}${it.id === 'loaded' ? ' Price rises with the level.' : ''}`;
    if (UPGRADE_CATS.includes(it.cat)) {
      return { cls: `obj ${it.rarity}`, html: `<div class="o-top"><span>${esc(CAT_LABEL[it.cat])}</span><span class="rarity-${it.rarity}">${it.rarity}</span></div><div class="o-stage">${figure(it.id, 0.86)}</div><div class="o-name">${esc(it.name)}</div><div class="o-desc">${esc(desc)}</div>` };
    }
    return { cls: `card-o ${it.rarity}`, html: `<div class="o-stage">${this.bigCard(it, desc)}</div>` };
  }

  // A card at reading size (shop, packs, reveals) and at hand size.
  bigCard(it, desc = it.desc) {
    return `<div class="pcard big ${it.rarity}"><i class="dot" style="background:${CAT_DOT[it.cat] || '#a6a59e'}"></i><span class="k">${esc(CAT_SHORT[it.cat] || 'Card')}</span><span class="r rarity-${it.rarity}">${it.rarity}</span><span class="art" style="background-position:${cardArt(it)}"></span><span class="nm">${esc(it.name)}</span><span class="tx">${esc(desc)}</span></div>`;
  }
  miniCard(it) {
    return `<div class="pcard ${it.rarity}"><i class="dot" style="background:${CAT_DOT[it.cat] || '#a6a59e'}"></i><span class="art" style="background-position:${cardArt(it)}"></span><span class="nm">${esc(it.name)}</span></div>`;
  }

  // Over the board: the shop between rounds, and the summary when a run ends.
  renderOverlay() {
    const g = this.game;
    const over = g.phase === 'gameover';
    const show = over || (g.phase === 'shop' && !this.boardReq && !(this.stamp && performance.now() < this.stamp.hold));
    this.$overlay.hidden = !show;
    this.$overlay.classList.toggle('over-mode', over);
    if (g.phase !== 'shop') this.peek = false;
    this.$overlay.classList.toggle('peek-mode', show && !over && !!this.peek);
    if (!show) { this.shopShown = false; return; }
    if (over) { this.$overlay.innerHTML = this.viewGameOver(); return; }
    if (this.benchOpen()) { this.$overlay.innerHTML = this.viewBench(); this.afterBench(); return; }
    // Looking at the board from the shop: the sheet steps aside and leaves one way back.
    if (this.peek) { this.$overlay.innerHTML = `<button class="peek-back" data-a="peek">Back to the shop<kbd>Esc</kbd></button>`; this.shopShown = false; return; }
    // A bought offer greys out under a Sold out stamp; it slams down the moment it is bought.
    const seen = this.soldSeen || (this.soldSeen = new Map());
    if (!this.shopShown) seen.clear();
    const now = performance.now();
    const stamp = (s, i) => {
      if (!s.sold) return '';
      const key = `${i}:${s.item?.id ?? s.group}`;
      if (!seen.has(key)) seen.set(key, this.shopShown ? now : -1e9);
      const age = now - seen.get(key);
      return `<b class="sold-stamp${age < 700 ? ' slam' : ''}" ${age < 700 ? `style="animation-delay:${-Math.round(age)}ms"` : ''}>Sold out</b>`;
    };
    const offers = g.shop.map((s, i) => {
      const price = g.slotPrice(s);
      const afford = g.budget >= price;
      const can = !s.sold && afford && !this.busy;
      const cost = price === Infinity ? 'max level' : `${price} VP`;
      const btn = `<button class="${can ? 'primary' : ''} buy" data-a="buy" data-i="${i}" ${can ? '' : 'disabled'}>${s.sold ? 'Sold out' : afford ? `Buy · ${cost}` : `${cost}<small>need ${price - g.budget} more</small>`}</button>`;
      if (s.kind === 'pack') {
        return `<div class="offer pack ${s.sold ? 'sold' : ''}"><div class="o-top"><span>Pack · ${esc(s.group)}</span><span>1 of 3</span></div>
          <div class="o-stage"><div class="sealed"><i></i><i></i><i><b>?</b></i></div></div>
          <div class="o-name">A pack of three</div><div class="o-desc">Open it after you buy, then keep one.</div>${btn}${stamp(s, i)}</div>`;
      }
      const art = this.offerArt(s.item);
      return `<div class="offer ${art.cls} ${s.sold ? 'sold' : ''}">${art.html}${btn}${stamp(s, i)}</div>`;
    }).join('');
    const e = g.earned;
    const sum = `Score ${g.vp} + unused rolls ${e.unusedRolls} + Storehouse ${e.storehouse}${e.river ? ` + River ${e.river}` : ''}${e.twinFortune ? ` + Twin Fortune ${e.twinFortune}` : ''}`;
    const keep = this.$overlay.querySelector('.shop')?.scrollTop || 0;
    this.$overlay.innerHTML = `<div class="shop" role="dialog" aria-label="The Shop">
      <div class="shop-head"><div><div class="eyebrow">Between rounds</div><h2>The Shop</h2></div>
        <div class="budget-box" title="${esc(sum)}"><div class="eyebrow">Budget</div><div class="budget">${g.budget}<small>VP</small></div></div></div>
      <div class="shop-grid" style="--n:${g.shop.length}">${offers}</div>
      <div class="shop-foot"><button data-a="reroll" ${g.budget >= g.rerollPrice ? '' : 'disabled'}>Reroll offers · ${g.rerollPrice} VP</button>
        <span class="sf-note"><b>Unspent VP is lost when you leave.</b> Dice, field and port upgrades ask for their target after you buy.</span>
        <button class="peek-btn" data-a="peek" title="Hide the shop and look at your island">View board</button>
        <button class="primary next-btn" data-a="leave" ${this.busy ? 'disabled' : ''} title="Close the shop and start the next round">${g.blind === 2 ? 'Next ante' : `Next: ${BLINDS[g.blind + 1]} round`}</button></div>
</div>`;
    const sh = this.$overlay.querySelector('.shop');
    if (sh && this.shopShown) sh.scrollTop = keep;
    this.shopShown = true;
  }

  // The end of a run: what stopped it, how far it got, and the way back in.
  viewGameOver() {
    const g = this.game;
    const due = g.tributeDue ? g.tributeDue() : [];
    const loose = due.every((p) => !p.type);
    const asked = loose
      ? `${due.map((p) => p.amount).join(' + ')} ${due.length > 1 ? 'cards of different resources' : `card${due[0]?.amount === 1 ? '' : 's'} of one resource`}`
      : due.map((p) => `${p.amount} ${p.type || 'of another resource'}`).join(' + ');
    const stat = (k, v, u = '') => `<div><dt>${k}</dt><dd>${v}${u ? `<small>${u}</small>` : ''}</dd></div>`;
    return `<div class="over" role="dialog" aria-label="Run over">
      <div class="eyebrow">Run over</div>
      <h2>The tribute went unpaid</h2>
      <p class="lead">The ${BLINDS[g.blind]} round of ante ${g.ante} asked for ${asked || 'more than you had'}${g.blind === 2 && g.boss ? `, under ${esc(g.boss.name)}` : ''}.</p>
      <dl class="over-stats">${stat('Rounds survived', g.roundsSurvived)}${stat('Ante reached', g.ante)}${stat('Final score', g.vp, 'VP')}</dl>
      <div class="over-foot"><button class="big center" data-a="again" title="The same seed gives the same board and dice if you make the same choices">Replay seed ${g.seed}</button><button class="primary big" data-a="fresh" data-primary>New run<kbd>Space</kbd></button></div>
    </div>`;
  }

  // ---------------------------------------------------------------- the table: lamp
  // One lamp over the board. Its colour drifts from amber toward ember over the antes, and the boss round turns it vermilion.
  renderMood() {
    const g = this.game;
    if (!g || !g.board) return;
    const t = Math.min(Math.max(g.ante - 1, 0) / 7, 1);
    const mix = (a, b) => a.map((v, i) => Math.round(v + (b[i] - v) * t)).join(',');
    const boss = g.blind === 2 && g.phase !== 'shop' && g.phase !== 'gameover';
    let rgb = mix([255, 168, 92], [236, 116, 66]), k = 1, vig = '12,13,15', va = (0.93 + t * 0.04).toFixed(2);
    if (g.phase === 'shop') { rgb = mix([255, 188, 110], [244, 150, 84]); k = 0.9; }
    if (g.phase === 'gameover') { rgb = '150,160,175'; k = 0.7; }
    if (boss) { rgb = '255,74,28'; k = 1.45; vig = '30,6,3'; va = '0.97'; }
    const s = this.$stage.style;
    s.setProperty('--lamp-rgb', rgb);
    s.setProperty('--lamp-k', k);
    s.setProperty('--vig-rgb', vig);
    s.setProperty('--vig-a', va);
    this.$stage.dataset.mood = boss ? 'boss' : g.phase;
  }

  // ---------------------------------------------------------------- hand
  renderHand() {
    const g = this.game;
    if (!g || !g.board) return;
    const cost = this.hoverCost;
    const now = performance.now();
    // resources
    const stacks = RES.map((r) => {
      const n = g.hand[r];
      const need = cost ? cost[r] || 0 : 0;
      let cards = '';
      if (n === 0) cards = `<div class="rcard empty" style="--c:var(--${r})"><i class="dot"></i><span class="nm">${cap(r)}</span></div>`;
      else {
        const under = Math.min(n - 1, 4);
        const seed = hs(r);
        // Duplicates stack straight up, a few pixels per card, squared to the one in front.
        for (let k = under; k >= 1; k--) cards += `<div class="rcard under" style="left:0;top:${-4 * k}px;z-index:${5 - k}"></div>`;
        // New cards fly in from the board on the layer beneath the hand (playMoments); the stack itself only pulses.
        cards += rcard(r, need > 0 && n >= need ? 'need' : '', 'z-index:10;', `data-ak="gain:${r} stack:${r}"`);
      }
      const short = need > n;
      const store = g.storehouse[r];
      const info = {
        kind: 'Resource',
        title: cap(r),
        desc: `Your ${r} cards. Build costs and tribute spend them; hover a build option to see which cards it would use.`,
        now: `${n} in hand${store ? ` · ${store} stored` : ''}`,
        lines: short ? [`Missing ${need - n} for the option you are hovering`] : [],
      };
      return `<div class="stack ${short ? 'short' : ''}" data-res="${r}" ${this.tipAttr(`res:${r}`, info)} data-hl="hand:${r} store:${r}">
        <div class="stack-cards">${cards}${n > 0 ? `<span class="count${n >= 100 ? ' l3' : ''}" data-ck="hand-${r}">${this.feel.value(`hand-${r}`, n)}</span>` : ''}</div>
        <span class="stack-label">${short ? `<b class="bad">need ${need - n} more</b>` : ''}${g.storehouse[r] ? ` <span class="store">+${g.storehouse[r]} stored</span>` : ''}&nbsp;</span></div>`;
    }).join('');
    const stored = RES.filter((r) => g.storehouse[r] > 0);
    const storeBox = stored.length ? `<div class="storebox"><div class="eyebrow">Storehouse</div>${stored.map((r) => `<span data-hl="store:${r}">${resDot(r)}${g.storehouse[r]} ${r}</span>`).join('')}<small>counts toward the tribute</small></div>` : '';
    const total = RES.reduce((s, r) => s + g.hand[r], 0);
    const countable = g.handCountable();
    // card slots
    const canPlay = g.canAct() && !this.busy;
    const sel = g.cards.some((c) => c.uid === this.selCard) ? this.selCard : null;
    const pcard = (it, name, tipKey, info, extra = '', hl = '', cls = '') => `<div class="pcard ${it.rarity} ${cls}" style="rotate:${tilt(hs(tipKey), .8)}deg;${this.hideCards.has(tipKey) ? 'visibility:hidden;' : ''}" data-ak="new:${tipKey}" ${this.tipAttr(tipKey, info)} ${hl}><i class="dot" style="background:${CAT_DOT[it.cat] || '#a6a59e'}"></i><span class="art" style="background-position:${cardArt(it)}"></span><span class="nm">${esc(name)}</span>${extra}</div>`;
    const cardSlots = Array.from({ length: g.limits.handSlots }, (_, i) => {
      const c = g.cards[i];
      if (!c) return `<div class="slot-wrap"><div class="slot empty"><span>Card slot</span></div></div>`;
      const it = ITEMS[c.id];
      const info = {
        kind: CAT_LABEL[it.cat] || 'Card',
        title: it.name,
        desc: it.desc,
        now: canPlay ? 'Playable now.' : 'Playable on your turn, when no roll is pending.',
        lines: [`Rarity: ${it.rarity}`, 'Or sell it for 1 resource of your choice: click the card, then Sell.'],
      };
      const picked = sel === c.uid;
      return `<div class="slot-wrap ${picked ? 'picked' : ''}">${pcard(it, it.name, `card:${c.uid}`, info, '', `data-hl="card:${c.uid}" data-a="pick-card" data-uid="${c.uid}" role="button" tabindex="0"`, picked ? 'sel' : '')}${picked ? `<div class="card-acts"><button class="small play ${canPlay ? 'primary' : ''}" data-a="play" data-uid="${c.uid}" ${canPlay ? '' : 'disabled'} title="${canPlay ? 'Play this card' : 'Cards can be played during your turn, when no roll is pending'}">Play</button><button class="small sell" data-a="sell" data-uid="${c.uid}" ${canPlay ? '' : 'disabled'} title="Discard this card and take 1 resource of your choice">Sell · +1</button></div>` : ''}</div>`;
    }).join('');
    const guildSlots = Array.from({ length: g.limits.guildSlots }, (_, i) => {
      const gd = g.guilds[i];
      if (!gd) return `<div class="slot-wrap"><div class="slot empty small-slot"><span>Guild slot</span></div></div>`;
      const it = ITEMS[gd.id];
      const now = this.guildNow(gd.id);
      const nm = `${it.name}${gd.data.terrain ? ` (${gd.data.terrain})` : ''}`;
      const info = { kind: 'Guild · always on', title: nm, desc: it.desc, now, lines: [`Rarity: ${it.rarity}`] };
      return `<div class="slot-wrap">${pcard(it, nm, `guild:${gd.uid}`, info)}</div>`;
    }).join('');
    this.$hand.innerHTML = `
      <section class="zone hz-res"><div class="zone-h">Hand <b title="Holding more than 7 cards when a 7 is rolled makes you discard half">${total} card${total === 1 ? '' : 's'}${countable > 7 ? ' · <span class="bad">a 7 discards half</span>' : ''}</b></div><div class="res-row">${stacks}${storeBox}</div></section>
      <section class="zone hz-cards" style="--grow:${g.limits.handSlots}"><div class="zone-h">Cards <b>${g.cards.length} of ${g.limits.handSlots}</b></div><div class="slots" style="--n:${g.limits.handSlots}">${cardSlots}</div></section>
      <section class="zone guilds" style="--grow:${g.limits.guildSlots}"><div class="zone-h">Guilds <b>${g.guilds.length} of ${g.limits.guildSlots}</b></div><div class="slots" style="--n:${g.limits.guildSlots}">${guildSlots}</div></section>
      `;
    this.renderHud();
    this.fitHand();
    this.$stage.style.setProperty('--hand-h', `${this.$hand.offsetHeight}px`);
    const lz = this.$hand.firstElementChild;
    this.$stage.style.setProperty('--hand-l', `${lz ? lz.offsetHeight : 160}px`);
    if (this.view && this.$hand.offsetHeight !== this._handH) { this._handH = this.$hand.offsetHeight; this.view.fit(); }
    this.applyHighlights();
    this.anim.sync(this.$hand);
  }

  // Score and titles (longest road, largest army) live in the top left corner, next to the menu button.
  renderHud() {
    if (this.$hud) this.$hud.innerHTML = `${this.vpBig()}${this.statCards()}`;
  }

  // The bottom bar scales (--hz) so that Hand, Cards and Guilds fill all the width left of the action card.
  fitHand() {
    const h = this.$hand;
    if (!h) return;
    if (window.innerWidth <= 900) { h.style.removeProperty('--hz'); return; }
    const kids = [...h.children];
    if (!kids.length) return;
    const gap = parseFloat(getComputedStyle(h).columnGap) || 0;
    h.classList.add('measuring'); // natural widths, before the zones stretch to fill the bar
    const width = (z) => { h.style.setProperty('--hz', z); return kids.reduce((a, k) => a + k.offsetWidth, 0) + gap * (kids.length - 1); };
    const avail = h.clientWidth - 36;
    const byH = (0.27 * window.innerHeight - 56) / 112; // the bar must not eat the board
    let lo = 0.5, hi = Math.max(0.5, Math.min(1.6, byH));
    if (width(hi) <= avail) lo = hi; // widest allowed already fits
    else for (let i = 0; i < 8; i++) { const mid = (lo + hi) / 2; if (width(mid) <= avail) lo = mid; else hi = mid; }
    const hz = lo;
    h.style.setProperty('--hz', hz.toFixed(3));
    h.classList.remove('measuring');
  }

  // ---------------------------------------------------------------- tutorial
  // True until the first roll of the run has been made: that is when the tutorial button is offered on the card.
  tutorialOffered() {
    const g = this.game;
    return !g.phase || g.phase === 'setup' || (g.ante === 1 && g.blind === 0 && g.rollsUsed === 0 && !g.lastRoll);
  }

  tutorialButton() {
    return `<button class="small ghost tut-btn ${this.tutSeen ? '' : 'new'}" data-a="tutorial">▶ Play tutorial</button>`;
  }

  startTutorial() {
    this.setMenu(false);
    this.tut = { i: 0 };
    this.renderTutorial();
  }

  endTutorial() {
    this.tut = null;
    this.tutSeen = true;
    try { localStorage.setItem('hd-tutorial', 'seen'); } catch { /* ignore */ }
    this.renderTutorial();
    this.render();
  }

  tutStep(d) {
    if (!this.tut) return;
    const i = this.tut.i + d;
    if (i >= TUTORIAL.length) return this.endTutorial();
    this.tut.i = Math.max(0, i);
    this.renderTutorial();
  }

  renderTutorial() {
    let el = this.$tut;
    if (!el) {
      el = this.$tut = document.createElement('div');
      el.id = 'tutorial';
      document.body.appendChild(el);
      addEventListener('resize', () => { this.fitHand(); this.$stage.style.setProperty('--hand-h', `${this.$hand.offsetHeight}px`); if (this.view) this.view.fit(); if (this.tut) this.renderTutorial(); });
    }
    if (!this.tut) { el.hidden = true; el.innerHTML = ''; return; }
    const s = TUTORIAL[this.tut.i];
    const q = (sel) => (sel ? document.querySelector(sel) : null);
    const target = q(s.sel) || q(s.fallback);
    let box = null;
    if (target) {
      const r = target.getBoundingClientRect();
      const r2 = s.alsoSel ? q(s.alsoSel)?.getBoundingClientRect() : null;
      const l = Math.min(r.left, r2 ? r2.left : r.left), t = Math.min(r.top, r2 ? r2.top : r.top);
      const rr = Math.max(r.right, r2 ? r2.right : r.right), b = Math.max(r.bottom, r2 ? r2.bottom : r.bottom);
      const pad = s.pad ?? 8;
      box = { l: l - pad, t: t - pad, w: rr - l + 2 * pad, h: b - t + 2 * pad };
    }
    const last = this.tut.i === TUTORIAL.length - 1;
    const dots = TUTORIAL.map((_, k) => `<i class="${k === this.tut.i ? 'on' : k < this.tut.i ? 'done' : ''}"></i>`).join('');
    el.hidden = false;
    el.innerHTML = `${box ? `<div class="tut-spot" style="left:${box.l}px;top:${box.t}px;width:${box.w}px;height:${box.h}px"></div>` : '<div class="tut-dim"></div>'}
      <div class="tut-card" role="dialog" aria-label="Tutorial"><div class="tut-step">Step ${this.tut.i + 1} of ${TUTORIAL.length}</div><h3>${s.title}</h3><p>${s.text}</p>
        <div class="tut-dots">${dots}</div>
        <div class="tut-nav"><button class="small ghost" data-a="tut-end">${last ? 'Close' : 'Skip'}</button><span class="sp"></span>${this.tut.i ? '<button class="small" data-a="tut-back">Back</button>' : ''}<button class="primary small" data-a="tut-next">${last ? 'Start playing' : 'Next'}</button></div></div>`;
    // place the card beside the highlighted part, inside the window
    const card = el.querySelector('.tut-card');
    const cw = card.offsetWidth, ch = card.offsetHeight, m = 14;
    let x = (innerWidth - cw) / 2, y = (innerHeight - ch) / 2;
    if (box) {
      const spots = [
        [box.l + box.w + m, box.t + box.h / 2 - ch / 2],
        [box.l - cw - m, box.t + box.h / 2 - ch / 2],
        [box.l + box.w / 2 - cw / 2, box.t - ch - m],
        [box.l + box.w / 2 - cw / 2, box.t + box.h + m],
      ];
      const fit = spots.find(([sx, sy]) => sx >= 8 && sy >= 8 && sx + cw <= innerWidth - 8 && sy + ch <= innerHeight - 8);
      if (fit) [x, y] = fit;
      else { x = Math.max(8, Math.min(innerWidth - cw - 8, box.l + 20)); y = Math.max(8, Math.min(innerHeight - ch - 8, box.t + 20)); }
    }
    card.style.left = `${Math.max(8, x)}px`;
    card.style.top = `${Math.max(8, y)}px`;
    card.querySelector('[data-a="tut-next"]').focus({ preventScroll: true });
  }

  // ---------------------------------------------------------------- drawer (log / dev tools)
  renderDrawer() {
    const g = this.game;
    if (!this.drawer) { this.$drawer.innerHTML = ''; return; }
    let body;
    if (this.drawer === 'log') {
      body = `<div class="log">${g.logLines.slice(-200).reverse().map((l) => `<div class="${l.cls}">${esc(l.msg)}</div>`).join('')}</div>`;
    } else {
      const opts = [1, 2, 3, 4, 5, 6].map((n) => `<option>${n}</option>`).join('');
      body = `<p class="small muted">Testing helpers. They change the run, so use them to set up situations, not to play.</p>
        <div><b class="small">Add resources</b><div class="row" style="margin-top:4px">${RES.map((r) => `<span class="row" style="gap:2px">${resDot(r)}<button class="small" data-a="dev-res" data-r="${r}" data-n="1">+1</button><button class="small" data-a="dev-res" data-r="${r}" data-n="5">+5</button></span>`).join('')}</div></div>
        <div><b class="small">Force next roll</b><div class="row" style="margin-top:4px"><select id="dev-d1">${opts}</select> + <select id="dev-d2">${opts}</select><button class="small" data-a="dev-force">Set</button>${g.devForce ? `<span class="small muted">${g.devForce.join('+')} queued</span>` : ''}</div></div>
        <div><b class="small">Give item</b><div class="row" style="margin-top:4px"><select id="dev-item" style="max-width:100%">${ITEM_LIST.map((i) => `<option value="${i.id}">${i.cat}: ${i.name}</option>`).join('')}</select><button class="small" data-a="dev-item" ${this.busy ? 'disabled' : ''}>Give</button></div></div>
        <div class="row"><button class="small" data-a="dev-shop" ${g.phase === 'turn' && !g.pendingRoll ? '' : 'disabled'}>Skip tribute → shop</button><button class="small" data-a="dev-budget" ${g.phase === 'shop' ? '' : 'disabled'}>+10 shop budget</button></div>
        <p class="small muted">Seed ${g.seed}</p>`;
    }
    this.$drawer.innerHTML = `<aside class="drawer"><div class="drawer-h"><button class="tab ${this.drawer === 'log' ? 'on' : ''}" data-a="drawer-tab" data-tab="log">Log</button>${this.dev || this.drawer === 'dev' ? `<button class="tab ${this.drawer === 'dev' ? 'on' : ''}" data-a="drawer-tab" data-tab="dev">Dev tools</button>` : ''}<button class="small ghost" style="margin-left:auto" data-a="close-drawer">Close</button></div><div class="drawer-b">${body}</div></aside>`;
  }

  // ---------------------------------------------------------------- dialogs
  renderModal() {
    let html = '';
    if (this.modal) html = this.renderIoModal(this.modal);
    else if (this.dialog === 'help') html = this.renderHelp();
    else if (this.dialog === 'new') html = this.renderNewRun();
    else if (this.dialog === 'title') html = this.renderTitle();
    this.$modal.innerHTML = html ? `<div class="modal-back ${this.dialog === 'title' && !this.modal ? 'title-back' : ''}">${html}</div>` : '';
  }

  // "Nudge: choose a die" → a small label for whose question it is, and the question as the heading.
  promptHead(prompt) {
    const k = prompt.indexOf(': ');
    if (k < 0) return `<h2>${esc(prompt)}</h2>`;
    return `<div class="eyebrow">${esc(prompt.slice(0, k))}</div><h2>${esc(cap(prompt.slice(k + 2)))}</h2>`;
  }

  renderIoModal(m) {
    const cancel = m.cancel ? '<button data-a="cancel-modal">Cancel</button>' : '';
    if (m.type === 'options') {
      // An opened pack: the three items as offers, like in the shop.
      if (m.options.length && m.options.every((o) => o.item && ITEMS[o.item])) {
        // The three lie face down at first and turn over one after another, without a click.
        m.pack = true;
        if (m.t0 == null) m.t0 = performance.now();
        const shown = this.packShown(m);
        const el = performance.now() - m.t0;
        const flip = (i) => (shown ? '' : `style="--fd:${Math.round(this.anim.ms(PACK_T.first + i * PACK_T.gap) - el)}ms;--fdur:${this.anim.ms(PACK_T.turn)}ms"`);
        return `<div class="modal pack-modal" role="dialog" aria-modal="true"><div class="eyebrow">Pack opened</div><h2>Keep one of three</h2>
          <div class="pack-grid">${m.options.map((o, i) => { const art = this.offerArt(ITEMS[o.item]); return `<button class="offer pick-offer ${art.cls}${shown ? '' : ' flip'}" ${flip(i)} data-a="opt" data-i="${i}">${art.html}<span class="take">Keep this</span></button>`; }).join('')}</div>
          <div class="modal-foot">${m.cancel ? '<button data-a="cancel-modal">Leave the pack</button>' : ''}</div></div>`;
      }
      // A choice of resource types: the resource cards themselves, as in the hand.
      if (m.options.length && m.options.every((o) => RES.includes(o.value))) {
        const have = (r) => this.game?.hand ? this.game.hand[r] : null;
        return `<div class="modal res-modal" role="dialog" aria-modal="true">${this.promptHead(m.prompt)}
          <div class="res-choice">${m.options.map((o, i) => `<button class="res-take" data-a="opt" data-i="${i}" data-r="${o.value}" ${o.disabled ? 'disabled' : ''} title="${esc(cap(o.value))}">${rcard(o.value, '', '')}${have(o.value) != null ? `<small>${have(o.value)} in hand</small>` : ''}</button>`).join('')}</div>
          ${cancel ? `<div class="modal-foot">${cancel}</div>` : ''}</div>`;
      }
      // Plain numbers (a die value, a token number) become a row of keys; everything else a list with name and detail.
      const nums = m.options.every((o) => /^[+−-]?\d+$/.test(String(o.label)));
      const row = (o, i) => {
        if (nums) return `<button data-a="opt" data-i="${i}" ${o.disabled ? 'disabled' : ''}>${esc(o.label)}</button>`;
        const [main, detail = ''] = String(o.label).split(' — ');
        const mt = main.match(/^(.*?)(?:\s+\(([^)]*)\))?$/);
        return `<button data-a="opt" data-i="${i}" ${RES.includes(o.value) ? `data-r="${o.value}"` : ''} ${o.disabled ? 'disabled' : ''}><b>${esc(cap(mt[1]))}${mt[2] ? `<small>${esc(mt[2])}</small>` : ''}</b>${detail ? `<span>${esc(detail)}</span>` : ''}</button>`;
      };
      return `<div class="modal" role="dialog" aria-modal="true">${this.promptHead(m.prompt)}<div class="opts ${nums ? 'nums' : ''}">${m.options.map(row).join('')}</div>${cancel ? `<div class="modal-foot">${cancel}</div>` : ''}</div>`;
    }
    if (m.type === 'face' || m.type === 'load' || m.type === 'die') return ''; // chosen on the dice: in the action card, or on the workbench over the shop
    if (m.type === 'resources') {
      const total = RES.reduce((s, r) => s + m.counts[r], 0);
      const full = (r) => total >= m.n || (m.max && m.counts[r] >= m.max[r]);
      const pp = Math.round((total / m.n) * 100);
      if (m.pp != null && m.pp !== pp) this.anim.play('pickp', [{ '--p': `${m.pp}%` }, { '--p': `${pp}%` }], { dur: 240 });
      m.pp = pp;
      return `<div class="modal" role="dialog" aria-modal="true">${this.promptHead(m.prompt)}<p class="pick-count"><b>${total}</b> of ${m.n} ${m.discard ? 'to discard' : 'chosen'}<i data-ak="pickp" style="--p:${pp}%"></i></p>
        <div class="picker">${RES.map((r) => `<div class="pick ${m.counts[r] ? 'has' : ''}"><button class="pick-add" data-a="res-inc" data-r="${r}" aria-label="Add one ${r}" ${full(r) ? 'disabled' : ''}>${rcard(r, 'sm', '')}</button><span class="n">${m.counts[r]}</span><div class="pm"><button data-a="res-dec" data-r="${r}" aria-label="One less ${r}" ${m.counts[r] ? '' : 'disabled'}>−</button><button data-a="res-inc" data-r="${r}" aria-label="One more ${r}" ${full(r) ? 'disabled' : ''}>+</button></div>${m.max ? `<span class="have">of ${m.max[r]}</span>` : ''}</div>`).join('')}</div>
        <div class="modal-foot">${cancel}<button class="primary" data-a="res-ok" ${total === m.n ? '' : 'disabled'}>${m.discard ? 'Discard' : 'Confirm'}</button></div></div>`;
    }
    return '';
  }

  // First thing a visitor sees: what this is, in three lines, and one button.
  renderTitle() {
    return `<div class="modal title-card" role="dialog" aria-modal="true" aria-label="Hex and Dice">
      <div class="eyebrow">A solo roguelite</div>
      <h1>Hex <i>&amp;</i> Dice</h1>
      <p class="lead">Build one island, bend the dice, pay the tribute. Miss a tribute and the run is over.</p>
      <ol class="title-steps"><li><b>Roll</b>Hexes pay the buildings next to them.</li><li><b>Build</b>Grow and trade between rolls.</li><li><b>Pay</b>Then spend your score in the shop.</li></ol>
      <div class="modal-foot"><button data-a="title-tutorial">Show me how</button><button class="primary" data-a="close-dialog">Start a run<kbd>Space</kbd></button></div></div>`;
  }

  renderNewRun() {
    const g = this.game;
    const mid = g && g.phase !== 'gameover' && g.phase !== 'setup';
    return `<div class="modal" role="dialog" aria-modal="true"><h2>Start a new run</h2>
      ${mid ? '<p class="callout bad">Your current run will end.</p>' : ''}
      <label class="field" for="new-seed"><span>Seed · optional</span><input id="new-seed" type="number" min="1" placeholder="Leave empty for a random island"></label>
      <p class="cap">The same seed gives the same board and dice.</p>
      <div class="modal-foot"><button data-a="close-dialog">Cancel</button><button class="primary" data-a="start-seed">Start run</button></div></div>`;
  }

  renderHelp() {
    return `<div class="modal help" role="dialog" aria-modal="true"><h2>How to play</h2>
      <p>Grow one island across an endless run. The card on the right guides you through every round:</p>
      <ol><li><b>Roll</b> the dice. Every hex with that number pays its resource to your adjacent buildings (settlement 1, city 2).</li>
      <li><b>Result</b> shows what the dice did and what you got. On a 7 the robber strikes: discard half if you hold more than 7 cards, and one of your hexes gets blocked.</li>
      <li><b>Build & trade</b> between rolls: build, trade with the bank (cheaper with ports), ship to the Storehouse, play cards. You get 4 rolls per round.</li>
      <li><b>Tribute</b>: pay what the run card shows, or the run ends. Each part needs a different resource type. Leftover cards stay in your hand.</li>
      <li><b>Losing streak:</b> if all 4 rolls of a round give you nothing, you get a free development card.</li>
      <li><b>Shop</b>: your score plus VP earned this round is your budget. Unspent VP is lost.</li></ol>
      <p>Each ante has three rounds: Small, Big and Boss. Bosses add a drawback for one round. Tributes grow every ante.</p>
      <p class="small muted">Keys: Enter or Space = the main button · Esc = cancel or close.</p>
      <div class="modal-foot"><button data-a="close-dialog" class="primary">Got it</button></div></div>`;
  }
}
