// Animation layer: things that fly, drop, flip and fade.
// Nothing here touches the rules. The game resolves first; this layer only replays what happened, so a fast
// player (or the simulation) is never held up by it. Three rules:
//   - one speed setting (normal / fast / off) scales every duration; prefers-reduced-motion counts as off;
//   - everything can be skipped (`skip()` finishes whatever is running or still waiting);
//   - the UI redraws itself with innerHTML, so animations on redrawn elements are registered by key
//     (`play`) and re-attached after each redraw (`sync`) at the point in time they had reached.

const STORE_KEY = 'hd-anim';
const SPEEDS = { normal: 1, fast: 0.5, off: 0 };
const EASE_OUT = 'cubic-bezier(.2, .8, .25, 1)';
const EASE_IN = 'cubic-bezier(.55, 0, .85, .45)';

export class Anim {
  constructor(stage) {
    this.speed = 'normal';
    try { const s = localStorage.getItem(STORE_KEY); if (s in SPEEDS) this.speed = s; } catch { /* storage can be blocked */ }
    this.mq = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : null;
    // Two layers: `low` lies on the table under the hand and the action card (cards slide in beneath the
    // stacks, so the count badges always stay on top); `top` is above everything (score orbs).
    this.low = document.createElement('div');
    this.low.id = 'fx';
    this.low.setAttribute('aria-hidden', 'true');
    const overlay = stage.querySelector('#overlay');
    if (overlay) overlay.after(this.low); else stage.appendChild(this.low);
    this.top = document.createElement('div');
    this.top.id = 'fx-top';
    this.top.setAttribute('aria-hidden', 'true');
    document.body.appendChild(this.top);
    this.live = new Set(); // running one-shot animations
    this.waits = new Map(); // timer id → fn, for steps that have not started yet
    this.keyed = new Map(); // key → { frames, opts, start, total }
    this.gen = 0; // counts skips: a sequence that started before a skip hurries through its remaining steps
    this.dims = 0; // how many reveals have the stage darkened right now
    this.applySpeed();
  }

  get reduced() { return !!this.mq?.matches; }
  get k() { return this.reduced ? 0 : SPEEDS[this.speed]; }
  get on() { return this.k > 0; }
  ms(n) { return Math.round(n * this.k); }
  get busy() { return this.live.size > 0 || this.waits.size > 0; }

  setSpeed(s) {
    if (!(s in SPEEDS)) return;
    this.speed = s;
    try { localStorage.setItem(STORE_KEY, s); } catch { /* ignore */ }
    this.applySpeed();
    if (!this.on) this.skip();
  }

  // CSS animations (dice, stamps, reveals) read --ak; with animations off they are cut to nothing.
  applySpeed() {
    const root = document.documentElement;
    root.style.setProperty('--ak', String(this.k));
    root.classList.toggle('anim-off', !this.on);
    root.dataset.anim = this.on ? this.speed : 'off';
  }

  // ---------------------------------------------------------------- steps and skipping
  // Runs `fn` after `ms` (already scaled by the caller, or raw with scale = true). A skip runs it at once.
  after(ms, fn, gen = null) {
    const t = gen != null && gen !== this.gen ? 0 : ms;
    if (!(t > 0)) { fn(); return; }
    const id = setTimeout(() => { this.waits.delete(id); fn(); }, t);
    this.waits.set(id, fn);
  }

  wait(ms, gen = null) { return new Promise((resolve) => this.after(ms, resolve, gen)); }

  // Finishes everything: waiting steps run now (in order), running animations jump to their end.
  skip() {
    this.gen++;
    let guard = 0;
    while ((this.waits.size || this.live.size) && guard++ < 50) {
      const waits = [...this.waits];
      this.waits.clear();
      for (const [id, fn] of waits) { clearTimeout(id); try { fn(); } catch (e) { console.error(e); } }
      for (const a of [...this.live]) { try { a.finish(); } catch { /* an animation without an end */ } this.live.delete(a); a._done?.(); }
    }
    for (const [key, a] of this.keyed) { a.start = -1e9; this.keyed.delete(key); }
    for (const el of document.querySelectorAll('[data-ak]')) for (const a of el.getAnimations?.() || []) if (a.id?.startsWith('ak:')) a.cancel();
  }

  // Drops everything without running it (a new game).
  reset() {
    for (const id of this.waits.keys()) clearTimeout(id);
    this.waits.clear();
    for (const a of this.live) { try { a.cancel(); } catch { /* ignore */ } }
    this.live.clear();
    this.keyed.clear();
    this.gen++;
    this.dims = 0;
    this.low.innerHTML = '';
    this.top.innerHTML = '';
  }

  // ---------------------------------------------------------------- one-shot animations on the layers
  // Adds a node to a layer. Coordinates passed to `at` are viewport pixels.
  add(html, layer = 'low', width = 0) {
    const host = layer === 'top' ? this.top : this.low;
    const el = document.createElement('div');
    el.className = 'fx-item';
    if (width) el.style.width = `${width}px`;
    el.innerHTML = html;
    host.appendChild(el);
    return el;
  }

  // A layer's own offset, to turn viewport coordinates into its local ones.
  origin(el) {
    const host = el.parentElement;
    if (host === this.top) return { x: 0, y: 0 };
    const r = host.getBoundingClientRect();
    return { x: r.left, y: r.top };
  }

  // transform string that puts a w-wide item (natural size) on a viewport rect
  place(el, rect, natW, extra = '') {
    const o = this.origin(el);
    const s = rect.width / natW;
    return `translate(${(rect.left - o.x).toFixed(1)}px, ${(rect.top - o.y).toFixed(1)}px) scale(${s.toFixed(4)}) ${extra}`.trim();
  }

  // Runs keyframes on a layer item; resolves when it ends (or is skipped). Durations are scaled here.
  run(el, frames, { dur = 400, delay = 0, ease = 'linear', keep = false, gen = null } = {}) {
    return new Promise((resolve) => {
      if (!el.animate || !this.on || (gen != null && gen !== this.gen)) { if (!keep) el.remove(); resolve(); return; }
      const a = el.animate(frames, { duration: Math.max(1, this.ms(dur)), delay: this.ms(delay), easing: ease, fill: 'both' });
      let done = false;
      a._done = () => { if (done) return; done = true; this.live.delete(a); if (!keep) el.remove(); resolve(); };
      this.live.add(a);
      a.onfinish = a._done;
      a.oncancel = a._done;
    });
  }

  // Flies an item from one viewport rect to another. `natW` is the item's natural width (it is scaled to the rects).
  fly(el, from, to, natW, { dur = 420, delay = 0, lift = 0, spin = 0, ease = EASE_OUT, fadeIn = true, keep = false, gen = null } = {}) {
    const mid = { left: (from.left + to.left) / 2, top: (from.top + to.top) / 2 - lift, width: (from.width + to.width) / 2 };
    const frames = [
      { transform: this.place(el, from, natW, `rotate(${spin}deg)`), opacity: fadeIn ? 0 : 1 },
      { transform: this.place(el, mid, natW, `rotate(${(spin / 2).toFixed(1)}deg)`), opacity: 1, offset: 0.5 },
      { transform: this.place(el, to, natW), opacity: 1 },
    ];
    if (fadeIn) frames.splice(1, 0, { opacity: 1, offset: 0.12 });
    return this.run(el, frames, { dur, delay, ease, keep, gen });
  }

  // A card pulled out of the hand: it rises from where it lay, then fades with a slight flare.
  lift(el, from, natW, { delay = 0, side = 0, dur = 520, gen = null } = {}) {
    const h = from.height || from.width * 1.37;
    const up = { left: from.left + side * from.width * 0.12, top: from.top - h * 0.62, width: from.width };
    const out = { left: up.left + side * from.width * 0.05, top: up.top - h * 0.16, width: from.width * 1.05 };
    return this.run(el, [
      { transform: this.place(el, from, natW), opacity: 1, filter: 'brightness(1)', easing: EASE_OUT },
      { transform: this.place(el, up, natW, `rotate(${side * 4}deg)`), opacity: 1, filter: 'brightness(1)', offset: 0.55, easing: 'ease-in' },
      { transform: this.place(el, out, natW, `rotate(${side * 5}deg)`), opacity: 0, filter: 'brightness(1.9)' },
    ], { dur, delay, gen });
  }

  // A glowing score orb: bursts out of its source, then homes in on the counter.
  orb(from, to, { delay = 0, dur = 620, seed = 0 } = {}) {
    const el = this.add('<i class="fx-orb"></i>', 'top');
    const ang = seed * 2.399963; // golden angle: the burst spreads evenly
    const rad = 26 + (seed % 5) * 7;
    const bx = from.x + Math.cos(ang) * rad, by = from.y + Math.sin(ang) * rad * 0.7 - 14;
    const t = (x, y, s) => `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px) scale(${s})`;
    return this.run(el, [
      { transform: t(from.x, from.y, 0.2), opacity: 0, easing: EASE_OUT },
      { transform: t(bx, by, 1), opacity: 1, offset: 0.3, easing: EASE_IN },
      { transform: t(to.x, to.y, 0.55), opacity: 1 },
    ], { dur, delay });
  }

  // ---------------------------------------------------------------- keyed animations on redrawn elements
  // Elements carry data-ak="key" (several keys separated by spaces). `play` starts one; `sync` re-attaches it
  // after a redraw, continuing where it was.
  // `delay` is scaled with the speed setting; `wait` is real milliseconds (time until the dice land, say).
  play(key, frames, { dur = 300, delay = 0, wait = 0, ease = EASE_OUT, pseudo = null } = {}) {
    if (!this.on) return;
    const d = Math.max(1, this.ms(dur)), w = this.ms(delay) + Math.max(0, wait);
    this.keyed.set(key, { frames, opts: { duration: d, delay: w, easing: ease, fill: 'backwards', ...(pseudo ? { pseudoElement: pseudo } : {}) }, start: performance.now(), total: d + w });
  }

  sync(root = document) {
    if (!this.keyed.size) return;
    const now = performance.now();
    for (const [key, a] of this.keyed) if (now - a.start >= a.total) this.keyed.delete(key);
    if (!this.keyed.size) return;
    for (const el of root.querySelectorAll('[data-ak]')) {
      for (const key of el.dataset.ak.split(' ')) {
        const a = this.keyed.get(key);
        if (!a || !el.animate) continue;
        const id = `ak:${key}`;
        if (el.getAnimations({ subtree: !!a.opts.pseudoElement }).some((x) => x.id === id)) continue;
        try {
          const an = el.animate(a.frames, a.opts);
          an.id = id;
          an.currentTime = now - a.start;
        } catch { /* a browser without pseudo-element animations simply shows the end state */ }
      }
    }
  }
}

export { EASE_OUT, EASE_IN };
